import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertProjectSchema, insertAssetSchema, insertAnalyticsSchema,
  insertTeamMemberSchema, insertBillingSchema, insertPaymentHistorySchema,
  insertSettingsSchema, insertActivitySchema, insertUserSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  app.get("/api/dashboard/metrics", async (_req, res) => {
    try {
      const assets = await storage.getAssets();
      const billing = await storage.getBilling();
      const analytics = await storage.getAnalytics(undefined, 7);
      
      const liveModels = assets.filter(a => a.status === "processed").length;
      const totalViews = analytics.reduce((sum, a) => sum + a.views, 0);
      const totalConversions = analytics.reduce((sum, a) => sum + a.conversions, 0);
      const storageUsed = billing?.storageUsed || 0;
      const conversionRate = totalViews > 0 ? ((totalConversions / totalViews) * 100).toFixed(1) : "0";
      
      res.json({
        liveModels,
        totalViews,
        storageUsed: `${storageUsed.toFixed(1)} GB`,
        conversionRate: `${conversionRate}%`,
        storagePercentage: billing ? ((storageUsed / billing.storageLimit) * 100).toFixed(0) : "0"
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/dashboard/chart-data", async (_req, res) => {
    try {
      const analytics = await storage.getAnalytics(undefined, 7);
      const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      const chartData = days.map((name, index) => {
        const dayData = analytics.filter(a => {
          const date = new Date(a.date);
          return date.getDay() === (index + 1) % 7;
        });
        const value = dayData.reduce((sum, a) => sum + a.views, 0);
        return { name, value };
      });
      res.json(chartData);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/dashboard/recent-uploads", async (_req, res) => {
    try {
      const assets = await storage.getAssets();
      const recentAssets = assets.slice(0, 4).map(asset => ({
        id: asset.id,
        name: asset.name,
        views: asset.views,
        status: asset.status,
        thumbnail: asset.thumbnail,
        createdAt: asset.createdAt
      }));
      res.json(recentAssets);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/dashboard/activities", async (_req, res) => {
    try {
      const activities = await storage.getActivities(10);
      res.json(activities);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/projects", async (_req, res) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getProject(Number(req.params.id));
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const data = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(data);
      await storage.createActivity({
        type: "project_created",
        message: `Project "${project.name}" created`,
        userId: 1
      });
      res.json(project);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.updateProject(Number(req.params.id), req.body);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      await storage.deleteProject(Number(req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/assets", async (req, res) => {
    try {
      const projectId = req.query.projectId ? Number(req.query.projectId) : undefined;
      const assets = await storage.getAssets(projectId);
      res.json(assets);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/assets/:id", async (req, res) => {
    try {
      const asset = await storage.getAsset(Number(req.params.id));
      if (!asset) {
        return res.status(404).json({ error: "Asset not found" });
      }
      res.json(asset);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/assets", async (req, res) => {
    try {
      const data = insertAssetSchema.parse(req.body);
      const asset = await storage.createAsset(data);
      await storage.createActivity({
        type: "model_uploaded",
        message: `Model "${asset.name}" uploaded`,
        assetId: asset.id,
        userId: 1
      });
      res.json(asset);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/assets/:id", async (req, res) => {
    try {
      const asset = await storage.updateAsset(Number(req.params.id), req.body);
      if (!asset) {
        return res.status(404).json({ error: "Asset not found" });
      }
      res.json(asset);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/assets/:id", async (req, res) => {
    try {
      await storage.deleteAsset(Number(req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/analytics", async (req, res) => {
    try {
      const assetId = req.query.assetId ? Number(req.query.assetId) : undefined;
      const days = req.query.days ? Number(req.query.days) : 7;
      const analytics = await storage.getAnalytics(assetId, days);
      
      const totalViews = analytics.reduce((sum, a) => sum + a.views, 0);
      const uniqueUsers = analytics.reduce((sum, a) => sum + a.uniqueUsers, 0);
      const avgSession = analytics.length > 0 
        ? Math.floor(analytics.reduce((sum, a) => sum + a.avgSessionDuration, 0) / analytics.length)
        : 0;
      const conversions = analytics.reduce((sum, a) => sum + a.conversions, 0);
      const conversionRate = totalViews > 0 ? ((conversions / totalViews) * 100).toFixed(1) : "0";
      
      const deviceTypes = analytics.reduce((acc: any, a) => {
        if (a.deviceType) {
          acc[a.deviceType] = (acc[a.deviceType] || 0) + a.views;
        }
        return acc;
      }, {});
      
      const countries = analytics.reduce((acc: any, a) => {
        if (a.country) {
          acc[a.country] = (acc[a.country] || 0) + a.views;
        }
        return acc;
      }, {});
      
      res.json({
        summary: {
          totalViews,
          uniqueUsers,
          avgSession: `${Math.floor(avgSession / 60)}m ${avgSession % 60}s`,
          conversionRate: `${conversionRate}%`
        },
        chartData: analytics.map(a => ({
          date: a.date,
          views: a.views,
          users: a.uniqueUsers
        })),
        deviceTypes,
        countries
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/team", async (_req, res) => {
    try {
      const members = await storage.getTeamMembers();
      res.json(members);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/team", async (req, res) => {
    try {
      const data = insertTeamMemberSchema.parse(req.body);
      const member = await storage.createTeamMember(data);
      res.json(member);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/team/:id", async (req, res) => {
    try {
      const member = await storage.updateTeamMember(Number(req.params.id), req.body);
      if (!member) {
        return res.status(404).json({ error: "Team member not found" });
      }
      res.json(member);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/team/:id", async (req, res) => {
    try {
      await storage.deleteTeamMember(Number(req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/billing", async (_req, res) => {
    try {
      const billing = await storage.getBilling();
      const payments = await storage.getPaymentHistory();
      res.json({ billing, payments });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/billing", async (req, res) => {
    try {
      const billing = await storage.updateBilling(req.body);
      res.json(billing);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/settings/:userId", async (req, res) => {
    try {
      const settings = await storage.getSettings(Number(req.params.userId));
      res.json(settings);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/settings/:userId", async (req, res) => {
    try {
      const settings = await storage.updateSettings(Number(req.params.userId), req.body);
      res.json(settings);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
