import { eq, desc, and, gte, sql } from "drizzle-orm";
import { db } from "./db";
import {
  users, projects, assets, analytics, teamMembers, billing, paymentHistory, settings, activities,
  type User, type InsertUser,
  type Project, type InsertProject,
  type Asset, type InsertAsset,
  type Analytics, type InsertAnalytics,
  type TeamMember, type InsertTeamMember,
  type Billing, type InsertBilling,
  type PaymentHistory, type InsertPaymentHistory,
  type Settings, type InsertSettings,
  type Activity, type InsertActivity,
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;
  
  getAssets(projectId?: number): Promise<Asset[]>;
  getAsset(id: number): Promise<Asset | undefined>;
  createAsset(asset: InsertAsset): Promise<Asset>;
  updateAsset(id: number, asset: Partial<InsertAsset>): Promise<Asset | undefined>;
  deleteAsset(id: number): Promise<boolean>;
  
  getAnalytics(assetId?: number, days?: number): Promise<Analytics[]>;
  createAnalytics(analytics: InsertAnalytics): Promise<Analytics>;
  
  getTeamMembers(): Promise<TeamMember[]>;
  getTeamMember(id: number): Promise<TeamMember | undefined>;
  createTeamMember(member: InsertTeamMember): Promise<TeamMember>;
  updateTeamMember(id: number, member: Partial<InsertTeamMember>): Promise<TeamMember | undefined>;
  deleteTeamMember(id: number): Promise<boolean>;
  
  getBilling(): Promise<Billing | undefined>;
  updateBilling(billing: Partial<InsertBilling>): Promise<Billing | undefined>;
  
  getPaymentHistory(): Promise<PaymentHistory[]>;
  createPaymentHistory(payment: InsertPaymentHistory): Promise<PaymentHistory>;
  
  getSettings(userId: number): Promise<Settings | undefined>;
  updateSettings(userId: number, settings: Partial<InsertSettings>): Promise<Settings | undefined>;
  
  getActivities(limit?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
}

export class DbStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined> {
    const result = await db.update(users).set(user).where(eq(users.id, id)).returning();
    return result[0];
  }

  async getProjects(): Promise<Project[]> {
    return db.select().from(projects).orderBy(desc(projects.updatedAt));
  }

  async getProject(id: number): Promise<Project | undefined> {
    const result = await db.select().from(projects).where(eq(projects.id, id));
    return result[0];
  }

  async createProject(project: InsertProject): Promise<Project> {
    const result = await db.insert(projects).values(project).returning();
    return result[0];
  }

  async updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined> {
    const result = await db.update(projects).set({ ...project, updatedAt: new Date() }).where(eq(projects.id, id)).returning();
    return result[0];
  }

  async deleteProject(id: number): Promise<boolean> {
    await db.delete(projects).where(eq(projects.id, id));
    return true;
  }

  async getAssets(projectId?: number): Promise<Asset[]> {
    if (projectId) {
      return db.select().from(assets).where(eq(assets.projectId, projectId)).orderBy(desc(assets.createdAt));
    }
    return db.select().from(assets).orderBy(desc(assets.createdAt));
  }

  async getAsset(id: number): Promise<Asset | undefined> {
    const result = await db.select().from(assets).where(eq(assets.id, id));
    return result[0];
  }

  async createAsset(asset: InsertAsset): Promise<Asset> {
    const result = await db.insert(assets).values(asset).returning();
    
    if (asset.projectId) {
      await db.update(projects)
        .set({ modelsCount: sql`${projects.modelsCount} + 1` })
        .where(eq(projects.id, asset.projectId));
    }
    
    return result[0];
  }

  async updateAsset(id: number, asset: Partial<InsertAsset>): Promise<Asset | undefined> {
    const result = await db.update(assets).set({ ...asset, updatedAt: new Date() }).where(eq(assets.id, id)).returning();
    return result[0];
  }

  async deleteAsset(id: number): Promise<boolean> {
    const asset = await this.getAsset(id);
    await db.delete(assets).where(eq(assets.id, id));
    
    if (asset?.projectId) {
      await db.update(projects)
        .set({ modelsCount: sql`${projects.modelsCount} - 1` })
        .where(eq(projects.id, asset.projectId));
    }
    
    return true;
  }

  async getAnalytics(assetId?: number, days: number = 7): Promise<Analytics[]> {
    const daysAgo = new Date();
    daysAgo.setDate(daysAgo.getDate() - days);
    
    if (assetId) {
      return db.select().from(analytics)
        .where(and(eq(analytics.assetId, assetId), gte(analytics.date, daysAgo)))
        .orderBy(desc(analytics.date));
    }
    return db.select().from(analytics)
      .where(gte(analytics.date, daysAgo))
      .orderBy(desc(analytics.date));
  }

  async createAnalytics(analyticsData: InsertAnalytics): Promise<Analytics> {
    const result = await db.insert(analytics).values(analyticsData).returning();
    return result[0];
  }

  async getTeamMembers(): Promise<TeamMember[]> {
    return db.select().from(teamMembers).orderBy(desc(teamMembers.createdAt));
  }

  async getTeamMember(id: number): Promise<TeamMember | undefined> {
    const result = await db.select().from(teamMembers).where(eq(teamMembers.id, id));
    return result[0];
  }

  async createTeamMember(member: InsertTeamMember): Promise<TeamMember> {
    const result = await db.insert(teamMembers).values({
      ...member,
      permissions: member.permissions || []
    }).returning();
    return result[0];
  }

  async updateTeamMember(id: number, member: Partial<InsertTeamMember>): Promise<TeamMember | undefined> {
    const updateData: any = { ...member };
    if (member.permissions) {
      updateData.permissions = member.permissions;
    }
    const result = await db.update(teamMembers).set(updateData).where(eq(teamMembers.id, id)).returning();
    return result[0];
  }

  async deleteTeamMember(id: number): Promise<boolean> {
    await db.delete(teamMembers).where(eq(teamMembers.id, id));
    return true;
  }

  async getBilling(): Promise<Billing | undefined> {
    const result = await db.select().from(billing).limit(1);
    return result[0];
  }

  async updateBilling(billingData: Partial<InsertBilling>): Promise<Billing | undefined> {
    const existing = await this.getBilling();
    if (existing) {
      const result = await db.update(billing).set(billingData).where(eq(billing.id, existing.id)).returning();
      return result[0];
    }
    const result = await db.insert(billing).values(billingData as InsertBilling).returning();
    return result[0];
  }

  async getPaymentHistory(): Promise<PaymentHistory[]> {
    return db.select().from(paymentHistory).orderBy(desc(paymentHistory.date));
  }

  async createPaymentHistory(payment: InsertPaymentHistory): Promise<PaymentHistory> {
    const result = await db.insert(paymentHistory).values(payment).returning();
    return result[0];
  }

  async getSettings(userId: number): Promise<Settings | undefined> {
    const result = await db.select().from(settings).where(eq(settings.userId, userId));
    return result[0];
  }

  async updateSettings(userId: number, settingsData: Partial<InsertSettings>): Promise<Settings | undefined> {
    const existing = await this.getSettings(userId);
    if (existing) {
      const result = await db.update(settings).set({ ...settingsData, updatedAt: new Date() }).where(eq(settings.userId, userId)).returning();
      return result[0];
    }
    const result = await db.insert(settings).values({ ...settingsData, userId } as InsertSettings).returning();
    return result[0];
  }

  async getActivities(limit: number = 10): Promise<Activity[]> {
    return db.select().from(activities).orderBy(desc(activities.createdAt)).limit(limit);
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const result = await db.insert(activities).values(activity).returning();
    return result[0];
  }
}

export const storage = new DbStorage();
