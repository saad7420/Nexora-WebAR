import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MoreVertical, Download, QrCode, ExternalLink } from "lucide-react";
import emptyStateImage from "@assets/generated_images/Empty_state_illustration_e579d9a0.png";

interface AssetCardProps {
  name: string;
  format: string;
  size: string;
  views: number;
  status: "processed" | "processing" | "failed";
  thumbnail?: string;
}

export default function AssetCard({ name, format, size, views, status, thumbnail }: AssetCardProps) {
  const statusColors = {
    processed: "bg-green-500/10 text-green-500 border-green-500/20",
    processing: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
    failed: "bg-red-500/10 text-red-500 border-red-500/20",
  };

  const statusLabels = {
    processed: "Ready",
    processing: "Processing",
    failed: "Failed",
  };

  return (
    <Card className="overflow-hidden hover-elevate active-elevate-2 transition-all group" data-testid={`asset-${name.toLowerCase().replace(/\s/g, '-')}`}>
      <div className="aspect-square bg-gradient-to-br from-primary/5 to-chart-2/5 relative">
        <img
          src={thumbnail || emptyStateImage}
          alt={name}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button variant="secondary" size="icon" className="h-8 w-8 backdrop-blur-sm" data-testid="button-asset-menu">
            <MoreVertical className="w-4 h-4" />
          </Button>
        </div>
        <div className="absolute top-2 left-2">
          <Badge className={statusColors[status]}>{statusLabels[status]}</Badge>
        </div>
      </div>
      
      <div className="p-4 space-y-3">
        <div>
          <h3 className="font-semibold mb-1 truncate">{name}</h3>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="uppercase">{format}</span>
            <span>•</span>
            <span>{size}</span>
            <span>•</span>
            <span>{views} views</span>
          </div>
        </div>
        
        {status === "processed" && (
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="flex-1" data-testid="button-qr">
              <QrCode className="w-4 h-4 mr-1" />
              QR
            </Button>
            <Button variant="outline" size="sm" className="flex-1" data-testid="button-link">
              <ExternalLink className="w-4 h-4 mr-1" />
              Link
            </Button>
            <Button variant="outline" size="sm" data-testid="button-download">
              <Download className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}
