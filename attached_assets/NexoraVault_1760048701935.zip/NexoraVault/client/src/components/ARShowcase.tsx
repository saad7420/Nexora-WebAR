import { Button } from "@/components/ui/button";
import { QrCode, ExternalLink, Maximize2 } from "lucide-react";

export default function ARShowcase() {
  return (
    <section className="py-24 bg-gradient-to-b from-background to-card/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Experience AR Magic
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            See how your products come to life in augmented reality. Try our interactive demo.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="relative rounded-3xl overflow-hidden border border-border bg-card shadow-2xl">
            <div className="aspect-video bg-gradient-to-br from-primary/10 via-card to-chart-2/10 flex items-center justify-center">
              <div className="text-center space-y-6 p-8">
                <div className="w-24 h-24 mx-auto rounded-2xl bg-gradient-to-br from-chart-2/30 to-primary/30 flex items-center justify-center backdrop-blur-sm border border-chart-2/30">
                  <Maximize2 className="w-12 h-12 text-chart-2" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">View in Your Space</h3>
                  <p className="text-muted-foreground">Click the button below to launch AR on mobile</p>
                </div>
                <Button size="lg" className="bg-chart-2 hover:bg-chart-2/90 text-background" data-testid="button-view-ar">
                  <Maximize2 className="mr-2 h-5 w-5" />
                  View in Your Space
                </Button>
              </div>
            </div>

            <div className="p-6 border-t border-border bg-card/80 backdrop-blur-sm">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="text-sm">
                    <div className="font-medium">Gourmet Sushi Platter</div>
                    <div className="text-muted-foreground">Example AR Model</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" data-testid="button-qr-code">
                    <QrCode className="mr-2 h-4 w-4" />
                    QR Code
                  </Button>
                  <Button variant="outline" size="sm" data-testid="button-copy-link">
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Copy Link
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
