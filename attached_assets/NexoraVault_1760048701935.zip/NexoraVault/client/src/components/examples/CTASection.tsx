import CTASection from "../CTASection";

export default function CTASectionExample() {
  return <CTASection />;
}
