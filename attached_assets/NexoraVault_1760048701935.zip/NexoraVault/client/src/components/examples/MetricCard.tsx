import MetricCard from "../MetricCard";
import { TrendingUp } from "lucide-react";

export default function MetricCardExample() {
  return (
    <MetricCard
      title="Total AR Launches"
      value="12,543"
      change="+12.5% from last month"
      changeType="positive"
      icon={TrendingUp}
    />
  );
}
