import AssetCard from "../AssetCard";

export default function AssetCardExample() {
  return (
    <AssetCard
      name="Gourmet Sushi Platter"
      format="GLB"
      size="3.2 MB"
      views={234}
      status="processed"
    />
  );
}
