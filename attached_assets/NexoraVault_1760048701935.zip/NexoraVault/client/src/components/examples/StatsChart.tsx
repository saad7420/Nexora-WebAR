import StatsChart from "../StatsChart";

export default function StatsChartExample() {
  const data = [
    { name: "Mon", value: 120 },
    { name: "Tue", value: 180 },
    { name: "Wed", value: 150 },
    { name: "Thu", value: 220 },
    { name: "Fri", value: 280 },
    { name: "Sat", value: 190 },
    { name: "Sun", value: 240 },
  ];

  return <StatsChart title="AR Views This Week" data={data} type="area" />;
}
