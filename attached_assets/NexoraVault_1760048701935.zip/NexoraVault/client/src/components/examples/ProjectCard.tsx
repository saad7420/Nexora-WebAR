import ProjectCard from "../ProjectCard";

export default function ProjectCardExample() {
  return (
    <ProjectCard
      name="Summer Specials 2025"
      assetsCount={12}
      views={1543}
      createdAt="2 days ago"
    />
  );
}
