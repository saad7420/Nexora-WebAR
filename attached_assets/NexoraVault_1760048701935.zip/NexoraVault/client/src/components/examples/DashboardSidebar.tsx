import DashboardSidebar from "../DashboardSidebar";

export default function DashboardSidebarExample() {
  return <DashboardSidebar />;
}
