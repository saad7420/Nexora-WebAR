import ARShowcase from "../ARShowcase";

export default function ARShowcaseExample() {
  return <ARShowcase />;
}
