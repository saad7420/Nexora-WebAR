import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FolderKanban, MoreVertical, Eye } from "lucide-react";

interface ProjectCardProps {
  name: string;
  assetsCount: number;
  views: number;
  createdAt: string;
}

export default function ProjectCard({ name, assetsCount, views, createdAt }: ProjectCardProps) {
  return (
    <Card className="p-6 hover-elevate active-elevate-2 transition-all group" data-testid={`project-${name.toLowerCase().replace(/\s/g, '-')}`}>
      <div className="flex items-start justify-between mb-4">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-chart-2/20 flex items-center justify-center group-hover:scale-110 transition-transform">
          <FolderKanban className="w-6 h-6 text-primary" />
        </div>
        <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity" data-testid="button-project-menu">
          <MoreVertical className="w-4 h-4" />
        </Button>
      </div>
      
      <h3 className="text-lg font-semibold mb-2">{name}</h3>
      
      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
        <span>{assetsCount} assets</span>
        <span>•</span>
        <span className="flex items-center gap-1">
          <Eye className="w-4 h-4" />
          {views.toLocaleString()}
        </span>
      </div>
      
      <div className="text-xs text-muted-foreground">
        Created {createdAt}
      </div>
    </Card>
  );
}
