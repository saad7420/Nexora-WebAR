import { Zap, Target, Brain, Cloud, FolderKanban, BarChart3, Globe, Shield } from "lucide-react";

export default function Features() {
  const features = [
    {
      icon: Zap,
      title: "Instant WebAR Links & QR Codes",
      description: "Generate shareable AR experiences in seconds with optimized WebAR links and QR codes.",
    },
    {
      icon: Target,
      title: "Realistic Lighting & Materials",
      description: "PBR materials and automated lighting baking for photorealistic AR presentations.",
    },
    {
      icon: Brain,
      title: "Auto-Optimized Models",
      description: "Intelligent texture compression, mesh decimation, and LOD generation for peak performance.",
    },
    {
      icon: Cloud,
      title: "Secure Cloud Hosting",
      description: "Enterprise-grade CDN delivery with 99.9% uptime and global edge locations.",
    },
    {
      icon: FolderKanban,
      title: "Project-Based Organization",
      description: "Manage AR assets by campaign, menu, or season with intuitive folder structures.",
    },
    {
      icon: BarChart3,
      title: "AR Analytics Dashboard",
      description: "Track views, session duration, device types, and engagement metrics in real-time.",
    },
    {
      icon: Globe,
      title: "Works Everywhere",
      description: "Compatible with iOS, Android, and desktop browsers. No app required.",
    },
    {
      icon: Shield,
      title: "Enterprise Security",
      description: "Role-based access control, audit logs, and SOC 2 compliance ready.",
    },
  ];

  return (
    <section id="features" className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Powerful Features
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Everything you need to create, manage, and analyze professional WebAR experiences
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="group p-6 rounded-2xl border border-border bg-card hover-elevate active-elevate-2 transition-all"
                data-testid={`feature-${index}`}
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-chart-2/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
