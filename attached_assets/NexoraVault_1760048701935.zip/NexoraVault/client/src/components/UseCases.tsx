import { UtensilsCrossed, ShoppingBag, Car, Home } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function UseCases() {
  const cases = [
    {
      icon: UtensilsCrossed,
      industry: "Restaurants",
      title: "AR Menus that Increase Orders",
      description: "Let diners see dishes in 3D before ordering. Boost engagement and reduce returns.",
      stat: "35% increase in orders",
    },
    {
      icon: ShoppingBag,
      industry: "E-Commerce",
      title: "Try Products Before Purchase",
      description: "Reduce returns with AR product previews. Show scale, texture, and details accurately.",
      stat: "40% fewer returns",
    },
    {
      icon: Car,
      industry: "Automotive",
      title: "Visualize Custom Parts",
      description: "Show custom wheels, spoilers, and modifications in AR before installation.",
      stat: "50% faster decisions",
    },
    {
      icon: Home,
      industry: "Real Estate",
      title: "See Spaces in Real Scale",
      description: "Walk through properties virtually. Visualize furniture and renovations.",
      stat: "60% more qualified leads",
    },
  ];

  return (
    <section id="use-cases" className="py-24 bg-card/50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Industry Use Cases
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Trusted by businesses across industries to deliver immersive AR experiences
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {cases.map((useCase, index) => {
            const Icon = useCase.icon;
            return (
              <div
                key={index}
                className="group p-8 rounded-3xl border border-border bg-card hover-elevate active-elevate-2 transition-all"
                data-testid={`use-case-${index}`}
              >
                <div className="flex items-start gap-6">
                  <div className="flex-shrink-0">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-chart-2/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Icon className="w-8 h-8 text-primary" />
                    </div>
                  </div>
                  <div className="flex-1 space-y-3">
                    <div className="text-sm font-medium text-chart-2">{useCase.industry}</div>
                    <h3 className="text-xl font-bold">{useCase.title}</h3>
                    <p className="text-muted-foreground">{useCase.description}</p>
                    <div className="pt-2 flex items-center justify-between">
                      <div className="text-2xl font-bold text-primary">{useCase.stat}</div>
                      <Button variant="ghost" size="sm" data-testid={`button-learn-more-${index}`}>
                        Learn More →
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
