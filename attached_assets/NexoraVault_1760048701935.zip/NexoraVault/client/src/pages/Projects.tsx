import DashboardSidebar from "@/components/DashboardSidebar";
import AssetCard from "@/components/AssetCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Upload, Grid3x3, List } from "lucide-react";
import { useState } from "react";
import { useTheme } from "@/components/ThemeProvider";
import { Moon, Sun } from "lucide-react";

export default function Projects() {
  const { theme, toggleTheme } = useTheme();
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  const assets = [
    { name: "Gourmet Sushi Platter", format: "GLB", size: "3.2 MB", views: 234, status: "processed" as const },
    { name: "Wagyu Steak Presentation", format: "GLB", size: "4.8 MB", views: 189, status: "processed" as const },
    { name: "Signature Cocktail", format: "GLTF", size: "2.1 MB", views: 156, status: "processing" as const },
    { name: "Chef's Special Dessert", format: "GLB", size: "3.7 MB", views: 298, status: "processed" as const },
    { name: "Appetizer Platter", format: "FBX", size: "5.2 MB", views: 142, status: "failed" as const },
    { name: "Seasonal Salad", format: "GLB", size: "2.9 MB", views: 203, status: "processed" as const },
  ];

  return (
    <div className="flex h-screen overflow-hidden">
      <DashboardSidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="border-b border-border bg-background/95 backdrop-blur-sm sticky top-0 z-10">
          <div className="px-8 py-4 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold">Summer Specials 2025</h1>
                <p className="text-sm text-muted-foreground">12 assets • 1,543 total views</p>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={toggleTheme}
                  data-testid="button-theme-toggle-projects"
                >
                  {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                </Button>
                <Button data-testid="button-upload-asset">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload Asset
                </Button>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search assets..."
                  className="pl-10"
                  data-testid="input-search-assets"
                />
              </div>
              <div className="flex items-center gap-1 border border-border rounded-lg p-1">
                <Button
                  variant={viewMode === "grid" ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("grid")}
                  data-testid="button-grid-view"
                >
                  <Grid3x3 className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                  data-testid="button-list-view"
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="p-8">
          <div className={viewMode === "grid" ? "grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" : "space-y-4"}>
            {assets.map((asset, index) => (
              <AssetCard key={index} {...asset} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
