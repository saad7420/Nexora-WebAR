import DashboardSidebar from "@/components/DashboardSidebar";
import UploadZone from "@/components/UploadZone";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useTheme } from "@/components/ThemeProvider";
import { Moon, Sun } from "lucide-react";

export default function Upload() {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="flex h-screen overflow-hidden">
      <DashboardSidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="border-b border-border bg-background/95 backdrop-blur-sm sticky top-0 z-10">
          <div className="flex items-center justify-between px-8 py-4">
            <div>
              <h1 className="text-2xl font-bold">Upload 3D Model</h1>
              <p className="text-sm text-muted-foreground">Convert your 3D models to WebAR</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              data-testid="button-theme-toggle-upload"
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        <div className="p-8 max-w-4xl mx-auto space-y-8">
          <UploadZone />

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-6">Asset Details</h3>
            <div className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="asset-name">Asset Name</Label>
                  <Input id="asset-name" placeholder="e.g., Gourmet Sushi Platter" data-testid="input-asset-name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="project">Project</Label>
                  <Select>
                    <SelectTrigger id="project" data-testid="select-project">
                      <SelectValue placeholder="Select project" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="summer">Summer Specials 2025</SelectItem>
                      <SelectItem value="main">Main Menu</SelectItem>
                      <SelectItem value="holiday">Holiday Promo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description (Optional)</Label>
                <Textarea
                  id="description"
                  placeholder="Add details about this model..."
                  rows={3}
                  data-testid="textarea-description"
                />
              </div>

              <div className="grid sm:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="price">Price (Optional)</Label>
                  <Input id="price" type="number" placeholder="0.00" data-testid="input-price" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select>
                    <SelectTrigger id="category" data-testid="select-category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="appetizer">Appetizer</SelectItem>
                      <SelectItem value="main">Main Course</SelectItem>
                      <SelectItem value="dessert">Dessert</SelectItem>
                      <SelectItem value="drink">Beverage</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="allergens">Allergens (Optional)</Label>
                  <Input id="allergens" placeholder="e.g., Fish, Soy" data-testid="input-allergens" />
                </div>
              </div>

              <div className="pt-6 flex gap-4">
                <Button className="flex-1" data-testid="button-generate-webar">Generate WebAR</Button>
                <Button variant="outline" data-testid="button-save-draft">Save as Draft</Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
