import DashboardSidebar from "@/components/DashboardSidebar";
import MetricCard from "@/components/MetricCard";
import StatsChart from "@/components/StatsChart";
import ProjectCard from "@/components/ProjectCard";
import { TrendingUp, FolderKanban, Eye, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/ThemeProvider";
import { Moon, Sun } from "lucide-react";

export default function Dashboard() {
  const { theme, toggleTheme } = useTheme();
  
  const metrics = [
    { title: "Total AR Launches", value: "12,543", change: "+12.5% from last month", changeType: "positive" as const, icon: TrendingUp },
    { title: "Active Projects", value: "24", change: "+3 this week", changeType: "positive" as const, icon: FolderKanban },
    { title: "Total Views", value: "45.2K", change: "+8.3% from last week", changeType: "positive" as const, icon: Eye },
    { title: "Conversions", value: "2,847", change: "98% success rate", changeType: "neutral" as const, icon: Zap },
  ];

  const chartData = [
    { name: "Mon", value: 120 },
    { name: "Tue", value: 180 },
    { name: "Wed", value: 150 },
    { name: "Thu", value: 220 },
    { name: "Fri", value: 280 },
    { name: "Sat", value: 190 },
    { name: "Sun", value: 240 },
  ];

  const projects = [
    { name: "Summer Specials 2025", assetsCount: 12, views: 1543, createdAt: "2 days ago" },
    { name: "Main Menu", assetsCount: 25, views: 3421, createdAt: "1 week ago" },
    { name: "Holiday Promo", assetsCount: 8, views: 892, createdAt: "3 days ago" },
    { name: "Cocktail Menu", assetsCount: 15, views: 2103, createdAt: "5 days ago" },
  ];

  return (
    <div className="flex h-screen overflow-hidden">
      <DashboardSidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="border-b border-border bg-background/95 backdrop-blur-sm sticky top-0 z-10">
          <div className="flex items-center justify-between px-8 py-4">
            <div>
              <h1 className="text-2xl font-bold">Dashboard</h1>
              <p className="text-sm text-muted-foreground">Welcome back! Here's your overview</p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                data-testid="button-theme-toggle-dashboard"
              >
                {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
              <Button data-testid="button-new-upload">+ New Upload</Button>
            </div>
          </div>
        </div>

        <div className="p-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {metrics.map((metric, index) => (
              <MetricCard key={index} {...metric} />
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <StatsChart title="AR Views This Week" data={chartData} type="area" />
            <StatsChart title="Conversion Trends" data={chartData} type="line" />
          </div>

          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold">Recent Projects</h2>
              <Button variant="ghost" data-testid="button-view-all">View All →</Button>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {projects.map((project, index) => (
                <ProjectCard key={index} {...project} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
