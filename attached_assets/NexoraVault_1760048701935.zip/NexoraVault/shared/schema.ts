import { pgTable, text, serial, integer, boolean, timestamp, real, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  profilePhoto: text("profile_photo"),
  role: text("role").notNull().default("viewer"),
  active: boolean("active").notNull().default(true),
  lastActive: timestamp("last_active").defaultNow(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  thumbnail: text("thumbnail"),
  modelsCount: integer("models_count").notNull().default(0),
  totalViews: integer("total_views").notNull().default(0),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const assets = pgTable("assets", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id),
  name: text("name").notNull(),
  description: text("description"),
  format: text("format").notNull(),
  fileSize: text("file_size").notNull(),
  filePath: text("file_path").notNull(),
  thumbnail: text("thumbnail"),
  status: text("status").notNull().default("processing"),
  views: integer("views").notNull().default(0),
  conversions: integer("conversions").notNull().default(0),
  lighting: text("lighting").notNull().default("auto"),
  scale: real("scale").notNull().default(1.0),
  background: text("background").notNull().default("transparent"),
  autoRotate: boolean("auto_rotate").notNull().default(true),
  webArLink: text("webar_link"),
  qrCode: text("qr_code"),
  price: real("price"),
  category: text("category"),
  allergens: text("allergens"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const analytics = pgTable("analytics", {
  id: serial("id").primaryKey(),
  assetId: integer("asset_id").references(() => assets.id),
  date: timestamp("date").defaultNow().notNull(),
  views: integer("views").notNull().default(0),
  uniqueUsers: integer("unique_users").notNull().default(0),
  avgSessionDuration: integer("avg_session_duration").notNull().default(0),
  conversions: integer("conversions").notNull().default(0),
  deviceType: text("device_type"),
  country: text("country"),
  city: text("city"),
});

export const teamMembers = pgTable("team_members", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  role: text("role").notNull().default("viewer"),
  permissions: json("permissions").$type<string[]>(),
  invitedBy: integer("invited_by").references(() => users.id),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const billing = pgTable("billing", {
  id: serial("id").primaryKey(),
  plan: text("plan").notNull().default("free"),
  amount: real("amount").notNull().default(0),
  billingCycle: text("billing_cycle").notNull().default("monthly"),
  nextBilling: timestamp("next_billing"),
  autoRenew: boolean("auto_renew").notNull().default(false),
  arModelsUsed: integer("ar_models_used").notNull().default(0),
  arModelsLimit: integer("ar_models_limit").notNull().default(3),
  storageUsed: real("storage_used").notNull().default(0),
  storageLimit: real("storage_limit").notNull().default(1),
  monthlyViews: integer("monthly_views").notNull().default(0),
  monthlyViewsLimit: integer("monthly_views_limit").notNull().default(100),
  teamMembers: integer("team_members").notNull().default(1),
  teamMembersLimit: integer("team_members_limit").notNull().default(1),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const paymentHistory = pgTable("payment_history", {
  id: serial("id").primaryKey(),
  amount: real("amount").notNull(),
  date: timestamp("date").defaultNow().notNull(),
  status: text("status").notNull().default("paid"),
  invoiceUrl: text("invoice_url"),
});

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  companyName: text("company_name"),
  language: text("language").notNull().default("en"),
  timezone: text("timezone").notNull().default("UTC"),
  notifications: json("notifications").$type<{
    email: boolean;
    push: boolean;
    weekly: boolean;
  }>(),
  apiKey: text("api_key"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(),
  message: text("message").notNull(),
  assetId: integer("asset_id").references(() => assets.id),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, createdAt: true, updatedAt: true });
export const insertAssetSchema = createInsertSchema(assets).omit({ id: true, createdAt: true, updatedAt: true });
export const insertAnalyticsSchema = createInsertSchema(analytics).omit({ id: true });
export const insertTeamMemberSchema = createInsertSchema(teamMembers).omit({ id: true, createdAt: true });
export const insertBillingSchema = createInsertSchema(billing).omit({ id: true, createdAt: true });
export const insertPaymentHistorySchema = createInsertSchema(paymentHistory).omit({ id: true });
export const insertSettingsSchema = createInsertSchema(settings).omit({ id: true, updatedAt: true });
export const insertActivitySchema = createInsertSchema(activities).omit({ id: true, createdAt: true });

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Asset = typeof assets.$inferSelect;
export type InsertAsset = z.infer<typeof insertAssetSchema>;
export type Analytics = typeof analytics.$inferSelect;
export type InsertAnalytics = z.infer<typeof insertAnalyticsSchema>;
export type TeamMember = typeof teamMembers.$inferSelect;
export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;
export type Billing = typeof billing.$inferSelect;
export type InsertBilling = z.infer<typeof insertBillingSchema>;
export type PaymentHistory = typeof paymentHistory.$inferSelect;
export type InsertPaymentHistory = z.infer<typeof insertPaymentHistorySchema>;
export type Settings = typeof settings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
