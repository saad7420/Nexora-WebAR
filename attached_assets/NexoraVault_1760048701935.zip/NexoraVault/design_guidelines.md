# Nexora Design Guidelines

## Design Approach: Reference-Based (Premium SaaS + WebAR Innovation)

**Primary References**: Linear (clean interfaces) + Stripe (sophisticated color usage) + Airbnb (card-based layouts)

**Design Philosophy**: Enterprise-grade WebAR platform with luxury tech aesthetic, emphasizing precision, professionalism, and cutting-edge AR capabilities.

---

## Color System (Dark-First Architecture)

### Dark Mode (Primary)
- **Background**: `#0F1720` (deep charcoal-navy)
- **Surface**: `#161B23` (elevated panels)
- **Dividers**: `#24292f` (subtle boundaries)
- **Text Primary**: `#F8FAFC` (soft white)
- **Text Muted**: `#98A0A8` (secondary info)

### Brand Accents
- **Primary**: `#6366F1` (blue-violet) - main CTAs, links, focus states
- **Accent Cyan**: `#22D3EE` - interactive elements, AR indicators, success states
- **Gold Premium**: `#D4AC0D` - sparingly for badges, featured tags, premium highlights

### Light Mode
- **Background**: `#FFFFFF`
- **Surface**: `#F7F9FB`
- **Text**: `#0F1720`
- **Primary**: `#6366F1` (consistent across themes)

**Note**: All colors maintain WCAG AA compliance. Use gold extremely sparingly to avoid dated appearance.

---

## Typography

- **Primary Font**: Inter (via Google Fonts CDN) - UI, body text
- **Display Font**: DM Sans (via Google Fonts CDN) - headings, hero text
- **Code/Mono**: JetBrains Mono - technical displays, file names

### Scale
- **Hero**: text-5xl to text-7xl (bold)
- **Section Headers**: text-3xl to text-4xl (semibold)
- **Body**: text-base to text-lg (normal)
- **Captions**: text-sm to text-xs (medium)

---

## Layout & Spacing

**Tailwind Units**: Standardize on `2, 4, 8, 12, 16, 20, 24, 32` for consistent rhythm.

### Container Strategy
- **Full-width sections**: `w-full` with inner `max-w-7xl mx-auto px-6`
- **Content sections**: `max-w-6xl`
- **Text content**: `max-w-prose`

### Vertical Rhythm
- **Section padding**: `py-20` (desktop), `py-12` (mobile)
- **Card spacing**: `gap-8` (desktop), `gap-6` (mobile)
- **Component padding**: `p-6` to `p-8`

---

## Component Library

### Cards & Panels
- **Background**: Surface color with subtle border `border-[#24292f]`
- **Glass Effect**: `backdrop-blur-lg bg-opacity-80` for overlays
- **Border Radius**: `rounded-xl` (12px) for cards, `rounded-2xl` (16px) for major sections
- **Elevation**: Subtle shadows `shadow-lg` with cyan glow for interactive states

### Buttons
- **Primary**: Blue-violet fill `bg-[#6366F1]` with hover lift effect
- **Secondary**: Outline `border-[#6366F1]` with backdrop blur on images
- **Icon Buttons**: Circular `w-10 h-10` with subtle hover scale
- **No custom hover states** - rely on built-in Button interactions

### Forms & Inputs
- **Background**: `bg-[#161B23]` (dark mode), `bg-[#F7F9FB]` (light mode)
- **Border**: `border-[#24292f]` with cyan focus ring
- **Height**: `h-12` for standard inputs
- **Labels**: `text-sm font-medium text-[#98A0A8]` above inputs

### Navigation
- **Top Bar**: Fixed header with glass morphism `backdrop-blur-md bg-[#0F1720]/90`
- **Sidebar**: `w-64` with nested navigation, active state with cyan accent
- **Breadcrumbs**: Small caps `text-xs uppercase tracking-wide`

### Data Display
- **Tables**: Minimal borders, zebra striping `even:bg-[#161B23]/50`
- **Charts**: Recharts with cyan/blue-violet gradients, smooth animations
- **Stats Cards**: Large numbers `text-3xl font-bold` with trend indicators

### AR Viewer Components
- **Model Container**: Full-bleed with transparent background for mobile AR
- **Controls**: Floating circular buttons with glass effect `backdrop-blur-lg`
- **"View in Your Space"**: Primary CTA with neon cyan glow effect
- **Loading State**: Skeleton with subtle pulse animation

---

## Animations (Minimal & Purposeful)

- **Hover Effects**: Subtle lift `hover:translate-y-[-2px]` on cards
- **Page Transitions**: Fade in `opacity-0 to opacity-100` (300ms)
- **Conversion Progress**: Linear progress bar with cyan gradient
- **AR Launch**: Brief scale-up `scale-95 to scale-100` (200ms)
- **Chart Entrance**: Stagger reveal for data points (500ms delay between series)

**NO** gratuitous animations, scroll triggers, or distracting effects.

---

## Page-Specific Layouts

### Landing Page (Marketing)
1. **Hero**: 80vh with large hero image (3D model preview or AR device mockup), centered headline, dual CTAs
2. **How It Works**: 3-column grid (desktop) with icons, collapses to stack (mobile)
3. **AR Showcase**: Interactive model-viewer embed with "View in Your Space" CTA
4. **Features Grid**: 2-3 columns with icons, benefits, and micro-copy
5. **Use Cases**: Asymmetric 2-column splits alternating image/text sides
6. **Social Proof**: Logo cloud or testimonial cards (2-column)
7. **CTA Section**: Full-width gradient background with primary action
8. **Footer**: 4-column grid (desktop) - About, Resources, Legal, Newsletter signup

### Dashboard (Admin/Client)
- **Sidebar + Main Content**: `grid-cols-[256px_1fr]`
- **Metric Cards**: 4-column grid `grid-cols-1 md:grid-cols-2 lg:grid-cols-4`
- **Charts Section**: 2-column `grid-cols-1 lg:grid-cols-2` for analytics
- **Data Tables**: Full-width with sticky header, pagination at bottom

### Upload Interface
- **Drag-Drop Zone**: Centered, dashed border with cyan accent on hover
- **Progress Indicators**: Horizontal bar with percentage and status text
- **Preview Grid**: Masonry layout for uploaded assets

### Asset Management
- **Grid View**: `grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4`
- **List View**: Table with thumbnail, name, stats, actions
- **Detail Panel**: Split `grid-cols-1 lg:grid-cols-[2fr_1fr]` - preview left, metadata right

---

## Images

### Landing Page Hero
- **Image**: High-quality 3D rendered dish (e.g., gourmet pasta or sushi platter) floating with AR grid overlay and soft cyan glow
- **Position**: Right side on desktop (60% width), full-width background on mobile
- **Style**: Photorealistic with transparent background, subtle shadow/reflection

### Dashboard
- **Empty States**: Minimalist illustrations (3D cube wireframe) with call-to-action
- **Asset Thumbnails**: Square `aspect-square` with rounded corners, generated from 3D preview

### Icons
- **Library**: Lucide React (CDN) for UI icons
- **AR Indicators**: Custom SVG for "View in AR" icon (cube with AR rays)

---

## Accessibility

- **Contrast Ratios**: All text meets WCAG AA (4.5:1 minimum)
- **Focus Indicators**: Cyan ring `ring-2 ring-[#22D3EE]` on all interactive elements
- **Dark Mode Consistency**: All form inputs and text fields maintain dark aesthetic
- **Alt Text**: Descriptive for all 3D previews and AR states
- **Keyboard Navigation**: Full tab order, escape to close modals

---

## Key Differentiators

1. **Glass Morphism UI**: Sophisticated blur effects on overlays and navigation
2. **Neon Cyan Accents**: Strategic use for AR-specific interactions and success states
3. **Luxury Blue-Violet Primary**: Modern tech identity distinct from generic SaaS blues
4. **Transparent AR Backgrounds**: Seamless mobile WebAR integration
5. **Project-Folder Hierarchy**: Clear visual organization with nested navigation
6. **Real-Time Visual Feedback**: Conversion progress, analytics updates with smooth transitions

This design system creates a premium, enterprise-ready AR platform that balances technical sophistication with approachable user experience.