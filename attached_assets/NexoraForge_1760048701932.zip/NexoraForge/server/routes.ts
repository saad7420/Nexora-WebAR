// Referenced from javascript_stripe blueprint for Stripe integration
import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import Stripe from "stripe";
import { 
  insertWorkspaceSchema, 
  insertProjectSchema, 
  insertModelSchema,
  insertWorkspaceMemberSchema,
  insertAnalyticsEventSchema,
  insertArLinkSchema
} from "@shared/schema";

// Stripe setup - optional for development
const stripe = process.env.STRIPE_SECRET_KEY
  ? new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: "2024-11-20.acacia",
    })
  : null;

// Multer setup for file uploads
const upload = multer({
  dest: "uploads/",
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.glb', '.gltf', '.fbx', '.obj', '.zip'];
    const ext = file.originalname.toLowerCase().substring(file.originalname.lastIndexOf('.'));
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only GLB, GLTF, FBX, OBJ, and ZIP files are allowed.'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // ============ Workspaces ============
  app.get("/api/workspaces", async (req: Request, res: Response) => {
    try {
      // For demo, return mock data for the first user
      const workspaces = await storage.getWorkspacesByOwnerId("demo-user-id");
      res.json(workspaces);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/workspaces", async (req: Request, res: Response) => {
    try {
      const data = insertWorkspaceSchema.parse(req.body);
      const workspace = await storage.createWorkspace(data);
      
      // Create default free subscription
      await storage.createSubscription({
        workspaceId: workspace.id,
        plan: "free",
        status: "active",
        modelLimit: 3,
        storageLimit: 100,
        currentModelCount: 0,
        currentStorageUsed: 0,
      });
      
      res.json(workspace);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/workspaces/:id", async (req: Request, res: Response) => {
    try {
      const workspace = await storage.updateWorkspace(req.params.id, req.body);
      res.json(workspace);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/workspaces/:id", async (req: Request, res: Response) => {
    try {
      await storage.deleteWorkspace(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ============ Workspace Members ============
  app.get("/api/workspaces/:workspaceId/members", async (req: Request, res: Response) => {
    try {
      const members = await storage.getWorkspaceMembers(req.params.workspaceId);
      res.json(members);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/workspaces/:workspaceId/members", async (req: Request, res: Response) => {
    try {
      const data = insertWorkspaceMemberSchema.parse({
        ...req.body,
        workspaceId: req.params.workspaceId,
      });
      const member = await storage.createWorkspaceMember(data);
      res.json(member);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/workspace-members/:id/role", async (req: Request, res: Response) => {
    try {
      const { role } = req.body;
      const member = await storage.updateWorkspaceMemberRole(req.params.id, role);
      res.json(member);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/workspace-members/:id", async (req: Request, res: Response) => {
    try {
      await storage.deleteWorkspaceMember(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ============ Projects ============
  app.get("/api/workspaces/:workspaceId/projects", async (req: Request, res: Response) => {
    try {
      const projects = await storage.getProjectsByWorkspaceId(req.params.workspaceId);
      res.json(projects);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/projects/:id", async (req: Request, res: Response) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/projects", async (req: Request, res: Response) => {
    try {
      const data = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(data);
      res.json(project);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/projects/:id", async (req: Request, res: Response) => {
    try {
      const project = await storage.updateProject(req.params.id, req.body);
      res.json(project);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/projects/:id", async (req: Request, res: Response) => {
    try {
      await storage.deleteProject(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ============ Models ============
  // Get all models for a workspace
  app.get("/api/workspaces/:workspaceId/models", async (req: Request, res: Response) => {
    try {
      const projects = await storage.getProjectsByWorkspaceId(req.params.workspaceId);
      const allModels = [];
      for (const project of projects) {
        const models = await storage.getModelsByProjectId(project.id);
        allModels.push(...models);
      }
      res.json(allModels);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/projects/:projectId/models", async (req: Request, res: Response) => {
    try {
      const models = await storage.getModelsByProjectId(req.params.projectId);
      res.json(models);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/models/:id", async (req: Request, res: Response) => {
    try {
      const model = await storage.getModel(req.params.id);
      if (!model) {
        return res.status(404).json({ message: "Model not found" });
      }
      res.json(model);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/models/upload", upload.single("file"), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const modelData = {
        ...insertModelSchema.parse(req.body),
        originalFileName: req.file.originalname,
        fileSize: req.file.size,
        fileFormat: req.file.originalname.split('.').pop()?.toLowerCase() || 'glb',
        status: "uploading" as const,
      };

      const model = await storage.createModel(modelData);

      // In a real implementation, trigger background job for conversion
      // For now, simulate with a status update
      setTimeout(async () => {
        await storage.updateModel(model.id, {
          status: "ready",
          glbUrl: `/models/${model.id}.glb`,
          usdzUrl: `/models/${model.id}.usdz`,
          thumbnailUrl: `/models/${model.id}-thumbnail.jpg`,
        });
      }, 3000);

      res.json(model);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/models/:id", async (req: Request, res: Response) => {
    try {
      const model = await storage.updateModel(req.params.id, req.body);
      res.json(model);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/models/:id", async (req: Request, res: Response) => {
    try {
      await storage.deleteModel(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ============ Analytics ============
  app.get("/api/workspaces/:workspaceId/analytics", async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const events = await storage.getAnalyticsByWorkspaceId(req.params.workspaceId, limit);
      res.json(events);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/projects/:projectId/analytics", async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const events = await storage.getAnalyticsByProjectId(req.params.projectId, limit);
      res.json(events);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/models/:modelId/analytics", async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const events = await storage.getAnalyticsByModelId(req.params.modelId, limit);
      res.json(events);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/analytics/track", async (req: Request, res: Response) => {
    try {
      const data = insertAnalyticsEventSchema.parse(req.body);
      const event = await storage.createAnalyticsEvent(data);
      res.json(event);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ============ Subscriptions ============
  app.get("/api/workspaces/:workspaceId/subscription", async (req: Request, res: Response) => {
    try {
      const subscription = await storage.getSubscriptionByWorkspaceId(req.params.workspaceId);
      res.json(subscription);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Stripe subscription creation (referenced from javascript_stripe blueprint)
  app.post("/api/create-subscription", async (req: Request, res: Response) => {
    try {
      if (!stripe) {
        return res.status(503).json({ message: "Stripe is not configured" });
      }

      const { workspaceId, priceId, userId } = req.body;

      // Get or create Stripe customer
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      let customerId = user.stripeCustomerId;
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: user.email,
          name: user.name || user.username,
        });
        customerId = customer.id;
        await storage.updateUserStripeInfo(userId, customerId);
      }

      // Create subscription
      const subscription = await stripe.subscriptions.create({
        customer: customerId,
        items: [{ price: priceId }],
        payment_behavior: 'default_incomplete',
        payment_settings: { save_default_payment_method: 'on_subscription' },
        expand: ['latest_invoice.payment_intent'],
      });

      // Update database
      await storage.updateSubscription(workspaceId, {
        stripeSubscriptionId: subscription.id,
        stripePriceId: priceId,
        status: subscription.status as any,
        currentPeriodStart: new Date(subscription.current_period_start * 1000),
        currentPeriodEnd: new Date(subscription.current_period_end * 1000),
      });

      const invoice = subscription.latest_invoice as Stripe.Invoice;
      const paymentIntent = invoice.payment_intent as Stripe.PaymentIntent;

      res.json({
        subscriptionId: subscription.id,
        clientSecret: paymentIntent?.client_secret,
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ============ AR Links ============
  app.get("/api/models/:modelId/ar-links", async (req: Request, res: Response) => {
    try {
      const links = await storage.getArLinksByModelId(req.params.modelId);
      res.json(links);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/ar-links", async (req: Request, res: Response) => {
    try {
      // Generate unique short code
      const shortCode = Math.random().toString(36).substring(2, 8);
      const data = insertArLinkSchema.parse({
        ...req.body,
        shortCode,
      });
      const link = await storage.createArLink(data);
      res.json(link);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Public AR link access
  app.get("/ar/:shortCode", async (req: Request, res: Response) => {
    try {
      const link = await storage.getArLinkByShortCode(req.params.shortCode);
      if (!link || !link.isActive) {
        return res.status(404).json({ message: "AR link not found or expired" });
      }
      
      const model = await storage.getModel(link.modelId);
      res.json({ link, model });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // ============ Help Articles ============
  app.get("/api/help/articles", async (req: Request, res: Response) => {
    try {
      const articles = await storage.getHelpArticles();
      res.json(articles);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/help/articles/:slug", async (req: Request, res: Response) => {
    try {
      const article = await storage.getHelpArticleBySlug(req.params.slug);
      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }
      res.json(article);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
