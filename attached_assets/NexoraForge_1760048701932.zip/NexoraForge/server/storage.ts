// Referenced from javascript_database blueprint - converted to DatabaseStorage
import { 
  users, workspaces, workspaceMembers, projects, models, analyticsEvents,
  subscriptions, arLinks, helpArticles,
  type User, type InsertUser,
  type Workspace, type InsertWorkspace,
  type WorkspaceMember, type InsertWorkspaceMember,
  type Project, type InsertProject,
  type Model, type InsertModel,
  type AnalyticsEvent, type InsertAnalyticsEvent,
  type Subscription, type InsertSubscription,
  type ArLink, type InsertArLink,
  type HelpArticle, type InsertHelpArticle
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStripeInfo(userId: string, stripeCustomerId: string): Promise<User>;
  
  // Workspaces
  getWorkspace(id: string): Promise<Workspace | undefined>;
  getWorkspacesByOwnerId(ownerId: string): Promise<Workspace[]>;
  createWorkspace(workspace: InsertWorkspace): Promise<Workspace>;
  updateWorkspace(id: string, workspace: Partial<InsertWorkspace>): Promise<Workspace>;
  deleteWorkspace(id: string): Promise<void>;
  
  // Workspace Members
  getWorkspaceMembers(workspaceId: string): Promise<WorkspaceMember[]>;
  createWorkspaceMember(member: InsertWorkspaceMember): Promise<WorkspaceMember>;
  updateWorkspaceMemberRole(id: string, role: "admin" | "editor" | "viewer"): Promise<WorkspaceMember>;
  deleteWorkspaceMember(id: string): Promise<void>;
  
  // Projects
  getProject(id: string): Promise<Project | undefined>;
  getProjectsByWorkspaceId(workspaceId: string): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, project: Partial<InsertProject>): Promise<Project>;
  deleteProject(id: string): Promise<void>;
  
  // Models
  getModel(id: string): Promise<Model | undefined>;
  getModelsByProjectId(projectId: string): Promise<Model[]>;
  createModel(model: InsertModel): Promise<Model>;
  updateModel(id: string, model: Partial<InsertModel>): Promise<Model>;
  deleteModel(id: string): Promise<void>;
  
  // Analytics
  createAnalyticsEvent(event: InsertAnalyticsEvent): Promise<AnalyticsEvent>;
  getAnalyticsByWorkspaceId(workspaceId: string, limit?: number): Promise<AnalyticsEvent[]>;
  getAnalyticsByProjectId(projectId: string, limit?: number): Promise<AnalyticsEvent[]>;
  getAnalyticsByModelId(modelId: string, limit?: number): Promise<AnalyticsEvent[]>;
  
  // Subscriptions
  getSubscriptionByWorkspaceId(workspaceId: string): Promise<Subscription | undefined>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  updateSubscription(id: string, subscription: Partial<InsertSubscription>): Promise<Subscription>;
  
  // AR Links
  getArLinkByShortCode(shortCode: string): Promise<ArLink | undefined>;
  getArLinksByModelId(modelId: string): Promise<ArLink[]>;
  createArLink(link: InsertArLink): Promise<ArLink>;
  updateArLink(id: string, link: Partial<InsertArLink>): Promise<ArLink>;
  
  // Help Articles
  getHelpArticles(): Promise<HelpArticle[]>;
  getHelpArticleBySlug(slug: string): Promise<HelpArticle | undefined>;
  createHelpArticle(article: InsertHelpArticle): Promise<HelpArticle>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserStripeInfo(userId: string, stripeCustomerId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ stripeCustomerId })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }
  
  // Workspaces
  async getWorkspace(id: string): Promise<Workspace | undefined> {
    const [workspace] = await db.select().from(workspaces).where(eq(workspaces.id, id));
    return workspace || undefined;
  }

  async getWorkspacesByOwnerId(ownerId: string): Promise<Workspace[]> {
    return await db.select().from(workspaces).where(eq(workspaces.ownerId, ownerId));
  }

  async createWorkspace(insertWorkspace: InsertWorkspace): Promise<Workspace> {
    const [workspace] = await db.insert(workspaces).values(insertWorkspace).returning();
    return workspace;
  }

  async updateWorkspace(id: string, updateData: Partial<InsertWorkspace>): Promise<Workspace> {
    const [workspace] = await db
      .update(workspaces)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(workspaces.id, id))
      .returning();
    return workspace;
  }

  async deleteWorkspace(id: string): Promise<void> {
    await db.delete(workspaces).where(eq(workspaces.id, id));
  }
  
  // Workspace Members
  async getWorkspaceMembers(workspaceId: string): Promise<WorkspaceMember[]> {
    return await db.select().from(workspaceMembers).where(eq(workspaceMembers.workspaceId, workspaceId));
  }

  async createWorkspaceMember(insertMember: InsertWorkspaceMember): Promise<WorkspaceMember> {
    const [member] = await db.insert(workspaceMembers).values(insertMember).returning();
    return member;
  }

  async updateWorkspaceMemberRole(id: string, role: "admin" | "editor" | "viewer"): Promise<WorkspaceMember> {
    const [member] = await db
      .update(workspaceMembers)
      .set({ role })
      .where(eq(workspaceMembers.id, id))
      .returning();
    return member;
  }

  async deleteWorkspaceMember(id: string): Promise<void> {
    await db.delete(workspaceMembers).where(eq(workspaceMembers.id, id));
  }
  
  // Projects
  async getProject(id: string): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project || undefined;
  }

  async getProjectsByWorkspaceId(workspaceId: string): Promise<Project[]> {
    return await db.select().from(projects).where(eq(projects.workspaceId, workspaceId)).orderBy(desc(projects.createdAt));
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const [project] = await db.insert(projects).values(insertProject).returning();
    return project;
  }

  async updateProject(id: string, updateData: Partial<InsertProject>): Promise<Project> {
    const [project] = await db
      .update(projects)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return project;
  }

  async deleteProject(id: string): Promise<void> {
    await db.delete(projects).where(eq(projects.id, id));
  }
  
  // Models
  async getModel(id: string): Promise<Model | undefined> {
    const [model] = await db.select().from(models).where(eq(models.id, id));
    return model || undefined;
  }

  async getModelsByProjectId(projectId: string): Promise<Model[]> {
    return await db.select().from(models).where(eq(models.projectId, projectId)).orderBy(desc(models.createdAt));
  }

  async createModel(insertModel: InsertModel): Promise<Model> {
    const [model] = await db.insert(models).values(insertModel).returning();
    return model;
  }

  async updateModel(id: string, updateData: Partial<InsertModel>): Promise<Model> {
    const [model] = await db
      .update(models)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(models.id, id))
      .returning();
    return model;
  }

  async deleteModel(id: string): Promise<void> {
    await db.delete(models).where(eq(models.id, id));
  }
  
  // Analytics
  async createAnalyticsEvent(insertEvent: InsertAnalyticsEvent): Promise<AnalyticsEvent> {
    const [event] = await db.insert(analyticsEvents).values(insertEvent).returning();
    return event;
  }

  async getAnalyticsByWorkspaceId(workspaceId: string, limit: number = 100): Promise<AnalyticsEvent[]> {
    return await db
      .select()
      .from(analyticsEvents)
      .where(eq(analyticsEvents.workspaceId, workspaceId))
      .orderBy(desc(analyticsEvents.timestamp))
      .limit(limit);
  }

  async getAnalyticsByProjectId(projectId: string, limit: number = 100): Promise<AnalyticsEvent[]> {
    return await db
      .select()
      .from(analyticsEvents)
      .where(eq(analyticsEvents.projectId, projectId))
      .orderBy(desc(analyticsEvents.timestamp))
      .limit(limit);
  }

  async getAnalyticsByModelId(modelId: string, limit: number = 100): Promise<AnalyticsEvent[]> {
    return await db
      .select()
      .from(analyticsEvents)
      .where(eq(analyticsEvents.modelId, modelId))
      .orderBy(desc(analyticsEvents.timestamp))
      .limit(limit);
  }
  
  // Subscriptions
  async getSubscriptionByWorkspaceId(workspaceId: string): Promise<Subscription | undefined> {
    const [subscription] = await db.select().from(subscriptions).where(eq(subscriptions.workspaceId, workspaceId));
    return subscription || undefined;
  }

  async createSubscription(insertSubscription: InsertSubscription): Promise<Subscription> {
    const [subscription] = await db.insert(subscriptions).values(insertSubscription).returning();
    return subscription;
  }

  async updateSubscription(id: string, updateData: Partial<InsertSubscription>): Promise<Subscription> {
    const [subscription] = await db
      .update(subscriptions)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(subscriptions.id, id))
      .returning();
    return subscription;
  }
  
  // AR Links
  async getArLinkByShortCode(shortCode: string): Promise<ArLink | undefined> {
    const [link] = await db.select().from(arLinks).where(eq(arLinks.shortCode, shortCode));
    return link || undefined;
  }

  async getArLinksByModelId(modelId: string): Promise<ArLink[]> {
    return await db.select().from(arLinks).where(eq(arLinks.modelId, modelId));
  }

  async createArLink(insertLink: InsertArLink): Promise<ArLink> {
    const [link] = await db.insert(arLinks).values(insertLink).returning();
    return link;
  }

  async updateArLink(id: string, updateData: Partial<InsertArLink>): Promise<ArLink> {
    const [link] = await db
      .update(arLinks)
      .set(updateData)
      .where(eq(arLinks.id, id))
      .returning();
    return link;
  }
  
  // Help Articles
  async getHelpArticles(): Promise<HelpArticle[]> {
    return await db.select().from(helpArticles).where(eq(helpArticles.isPublished, true)).orderBy(helpArticles.order);
  }

  async getHelpArticleBySlug(slug: string): Promise<HelpArticle | undefined> {
    const [article] = await db.select().from(helpArticles).where(eq(helpArticles.slug, slug));
    return article || undefined;
  }

  async createHelpArticle(insertArticle: InsertHelpArticle): Promise<HelpArticle> {
    const [article] = await db.insert(helpArticles).values(insertArticle).returning();
    return article;
  }
}

export const storage = new DatabaseStorage();
