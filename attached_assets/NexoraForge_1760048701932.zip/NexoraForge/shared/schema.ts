import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const userRoleEnum = pgEnum("user_role", ["admin", "editor", "viewer"]);
export const modelStatusEnum = pgEnum("model_status", ["uploading", "processing", "ready", "error"]);
export const subscriptionPlanEnum = pgEnum("subscription_plan", ["free", "basic", "pro", "enterprise"]);
export const subscriptionStatusEnum = pgEnum("subscription_status", ["active", "canceled", "past_due", "trialing"]);

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  avatarUrl: text("avatar_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  stripeCustomerId: text("stripe_customer_id"),
});

// Workspaces table (top-level client/business)
export const workspaces = pgTable("workspaces", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  logoUrl: text("logo_url"),
  ownerId: varchar("owner_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Workspace members (team collaboration)
export const workspaceMembers = pgTable("workspace_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  role: userRoleEnum("role").notNull().default("viewer"),
  invitedAt: timestamp("invited_at").defaultNow().notNull(),
  acceptedAt: timestamp("accepted_at"),
});

// Projects table (inside workspace - e.g., "Summer Menu 2025")
export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description"),
  thumbnailUrl: text("thumbnail_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// 3D Models table (assets inside projects)
export const models = pgTable("models", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description"),
  price: text("price"),
  category: text("category"),
  allergenTags: text("allergen_tags").array(),
  
  // File information
  originalFileName: text("original_file_name").notNull(),
  fileSize: integer("file_size").notNull(), // in bytes
  fileFormat: text("file_format").notNull(), // glb, gltf, fbx, obj
  
  // Processed files
  glbUrl: text("glb_url"),
  usdzUrl: text("usdz_url"),
  thumbnailUrl: text("thumbnail_url"),
  
  // AR settings
  scale: text("scale").default("1"),
  placement: text("placement").default("table"), // table, floor
  backgroundEnvironment: text("background_environment").default("studio"), // studio, transparent, custom
  
  // Hotspots for AR annotations
  hotspots: jsonb("hotspots").default(sql`'[]'::jsonb`), // Array of {id, position, text, link}
  
  // Status and metadata
  status: modelStatusEnum("status").notNull().default("uploading"),
  conversionError: text("conversion_error"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Analytics events table (track AR launches, views, interactions)
export const analyticsEvents = pgTable("analytics_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  modelId: varchar("model_id").notNull().references(() => models.id, { onDelete: "cascade" }),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  workspaceId: varchar("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
  
  eventType: text("event_type").notNull(), // view, ar_launch, hotspot_tap, share
  eventData: jsonb("event_data"), // Additional data about the event
  
  // Session information
  sessionId: text("session_id"),
  duration: integer("duration"), // in seconds
  
  // Device/location info
  userAgent: text("user_agent"),
  deviceType: text("device_type"), // mobile, tablet, desktop
  country: text("country"),
  
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Subscriptions table (Stripe integration)
export const subscriptions = pgTable("subscriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
  
  plan: subscriptionPlanEnum("plan").notNull().default("free"),
  status: subscriptionStatusEnum("status").notNull().default("trialing"),
  
  stripeSubscriptionId: text("stripe_subscription_id"),
  stripePriceId: text("stripe_price_id"),
  
  // Quotas and usage
  modelLimit: integer("model_limit").default(3), // Free tier: 3 models
  storageLimit: integer("storage_limit").default(100), // in MB
  currentModelCount: integer("current_model_count").default(0),
  currentStorageUsed: integer("current_storage_used").default(0), // in MB
  
  // Billing period
  currentPeriodStart: timestamp("current_period_start"),
  currentPeriodEnd: timestamp("current_period_end"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// AR Links/QR Codes table (shareable links)
export const arLinks = pgTable("ar_links", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  modelId: varchar("model_id").notNull().references(() => models.id, { onDelete: "cascade" }),
  
  shortCode: text("short_code").notNull().unique(), // e.g., "abc123" for ar.nexora.app/abc123
  qrCodeUrl: text("qr_code_url"),
  
  // Branding customization
  customLogoUrl: text("custom_logo_url"),
  customBackgroundColor: text("custom_background_color"),
  
  isActive: boolean("is_active").default(true),
  expiresAt: timestamp("expires_at"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Help/Support articles table
export const helpArticles = pgTable("help_articles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  content: text("content").notNull(),
  category: text("category").notNull(), // getting-started, uploading, customization, troubleshooting
  videoUrl: text("video_url"),
  order: integer("order").default(0),
  isPublished: boolean("is_published").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  ownedWorkspaces: many(workspaces),
  workspaceMemberships: many(workspaceMembers),
}));

export const workspacesRelations = relations(workspaces, ({ one, many }) => ({
  owner: one(users, {
    fields: [workspaces.ownerId],
    references: [users.id],
  }),
  members: many(workspaceMembers),
  projects: many(projects),
  subscription: one(subscriptions),
  analytics: many(analyticsEvents),
}));

export const workspaceMembersRelations = relations(workspaceMembers, ({ one }) => ({
  workspace: one(workspaces, {
    fields: [workspaceMembers.workspaceId],
    references: [workspaces.id],
  }),
  user: one(users, {
    fields: [workspaceMembers.userId],
    references: [users.id],
  }),
}));

export const projectsRelations = relations(projects, ({ one, many }) => ({
  workspace: one(workspaces, {
    fields: [projects.workspaceId],
    references: [workspaces.id],
  }),
  models: many(models),
  analytics: many(analyticsEvents),
}));

export const modelsRelations = relations(models, ({ one, many }) => ({
  project: one(projects, {
    fields: [models.projectId],
    references: [projects.id],
  }),
  analytics: many(analyticsEvents),
  arLinks: many(arLinks),
}));

export const analyticsEventsRelations = relations(analyticsEvents, ({ one }) => ({
  model: one(models, {
    fields: [analyticsEvents.modelId],
    references: [models.id],
  }),
  project: one(projects, {
    fields: [analyticsEvents.projectId],
    references: [projects.id],
  }),
  workspace: one(workspaces, {
    fields: [analyticsEvents.workspaceId],
    references: [workspaces.id],
  }),
}));

export const subscriptionsRelations = relations(subscriptions, ({ one }) => ({
  workspace: one(workspaces, {
    fields: [subscriptions.workspaceId],
    references: [workspaces.id],
  }),
}));

export const arLinksRelations = relations(arLinks, ({ one }) => ({
  model: one(models, {
    fields: [arLinks.modelId],
    references: [models.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertWorkspaceSchema = createInsertSchema(workspaces).omit({ id: true, createdAt: true, updatedAt: true });
export const insertWorkspaceMemberSchema = createInsertSchema(workspaceMembers).omit({ id: true, invitedAt: true });
export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, createdAt: true, updatedAt: true });
export const insertModelSchema = createInsertSchema(models).omit({ id: true, createdAt: true, updatedAt: true });
export const insertAnalyticsEventSchema = createInsertSchema(analyticsEvents).omit({ id: true, timestamp: true });
export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({ id: true, createdAt: true, updatedAt: true });
export const insertArLinkSchema = createInsertSchema(arLinks).omit({ id: true, createdAt: true });
export const insertHelpArticleSchema = createInsertSchema(helpArticles).omit({ id: true, createdAt: true, updatedAt: true });

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertWorkspace = z.infer<typeof insertWorkspaceSchema>;
export type Workspace = typeof workspaces.$inferSelect;

export type InsertWorkspaceMember = z.infer<typeof insertWorkspaceMemberSchema>;
export type WorkspaceMember = typeof workspaceMembers.$inferSelect;

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

export type InsertModel = z.infer<typeof insertModelSchema>;
export type Model = typeof models.$inferSelect;

export type InsertAnalyticsEvent = z.infer<typeof insertAnalyticsEventSchema>;
export type AnalyticsEvent = typeof analyticsEvents.$inferSelect;

export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;

export type InsertArLink = z.infer<typeof insertArLinkSchema>;
export type ArLink = typeof arLinks.$inferSelect;

export type InsertHelpArticle = z.infer<typeof insertHelpArticleSchema>;
export type HelpArticle = typeof helpArticles.$inferSelect;
