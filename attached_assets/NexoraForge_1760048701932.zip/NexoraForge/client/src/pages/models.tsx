import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Filter, Upload, Eye, Share2, MoreVertical } from "lucide-react";
import { Link } from "wouter";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useWorkspaceModels, useDeleteModel } from "@/hooks/use-models";
import { useWorkspaceContext } from "@/contexts/workspace-context";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

export default function Models() {
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  const { currentWorkspaceId, isLoading: workspaceLoading } = useWorkspaceContext();

  // Get all models for this workspace
  const { data: models = [], isLoading: modelsLoading } = useWorkspaceModels(currentWorkspaceId);
  const deleteModel = useDeleteModel();

  const handleDelete = async (id: string) => {
    try {
      await deleteModel.mutateAsync(id);
      toast({
        title: "Model deleted",
        description: "The 3D model has been successfully deleted.",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const isLoading = workspaceLoading || modelsLoading;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold" data-testid="text-models-title">
            3D Models
          </h1>
          <p className="text-muted-foreground mt-1">
            Upload and manage your 3D AR models
          </p>
        </div>
        <Link href="/models/upload">
          <Button data-testid="button-upload-model">
            <Upload className="h-4 w-4 mr-2" />
            Upload Model
          </Button>
        </Link>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search models..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-models"
          />
        </div>
        <Button variant="outline" data-testid="button-filter">
          <Filter className="h-4 w-4 mr-2" />
          Filter
        </Button>
      </div>

      {/* Models Grid */}
      {isLoading ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <Skeleton className="aspect-square w-full" />
              <CardContent className="pt-4">
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : models.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="rounded-full bg-primary/10 p-6 mb-4">
              <Upload className="h-12 w-12 text-primary" />
            </div>
            <h3 className="text-xl font-display font-semibold mb-2">
              No 3D models yet
            </h3>
            <p className="text-muted-foreground text-center max-w-md mb-6">
              Upload your first 3D model to create an immersive WebAR experience. Supports GLB, GLTF, FBX, and OBJ formats.
            </p>
            <Link href="/models/upload">
              <Button size="lg" data-testid="button-upload-first-model">
                <Upload className="h-5 w-5 mr-2" />
                Upload 3D Model
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {models.map((model) => (
            <Card key={model.id} className="hover-elevate transition-all" data-testid={`card-model-${model.id}`}>
              <div className="aspect-square bg-muted rounded-t-lg relative overflow-hidden">
                {model.thumbnailUrl ? (
                  <img src={model.thumbnailUrl} alt={model.name} className="object-cover w-full h-full" />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <Plus className="h-12 w-12 text-muted-foreground" />
                  </div>
                )}
                <Badge 
                  className="absolute top-3 right-3" 
                  variant={model.status === "ready" ? "default" : "secondary"}
                  data-testid={`badge-status-${model.id}`}
                >
                  {model.status.charAt(0).toUpperCase() + model.status.slice(1)}
                </Badge>
              </div>
              <CardContent className="pt-4">
                <h3 className="font-semibold mb-1 line-clamp-1">{model.name}</h3>
                <p className="text-xs text-muted-foreground font-mono mb-3">
                  {(model.fileSize / 1024 / 1024).toFixed(2)} MB • {model.fileFormat.toUpperCase()}
                </p>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1" data-testid={`button-preview-${model.id}`}>
                    <Eye className="h-3 w-3 mr-1" />
                    Preview
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1" data-testid={`button-share-${model.id}`}>
                    <Share2 className="h-3 w-3 mr-1" />
                    Share
                  </Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm" data-testid={`button-model-menu-${model.id}`}>
                        <MoreVertical className="h-3 w-3" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>Edit</DropdownMenuItem>
                      <DropdownMenuItem>Download</DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-destructive"
                        onClick={() => handleDelete(model.id)}
                      >
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
