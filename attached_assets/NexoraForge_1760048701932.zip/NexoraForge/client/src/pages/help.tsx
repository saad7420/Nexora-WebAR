import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Book, Video, MessageCircle, ExternalLink, ChevronRight } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const categories = [
  {
    title: "Getting Started",
    icon: Book,
    articles: [
      "Creating your first workspace",
      "Uploading 3D models",
      "Understanding AR settings",
    ],
  },
  {
    title: "Video Tutorials",
    icon: Video,
    articles: [
      "Complete platform walkthrough",
      "Model optimization best practices",
      "Sharing AR experiences",
    ],
  },
];

const faqs = [
  {
    question: "What 3D file formats are supported?",
    answer:
      "Nexora supports GLB, GLTF, FBX, and OBJ file formats. For best results, we recommend using GLB format as it's optimized for web delivery.",
  },
  {
    question: "How long does model conversion take?",
    answer:
      "Model conversion typically takes 2-5 minutes depending on the complexity and file size. You'll receive a notification when the conversion is complete.",
  },
  {
    question: "What's the maximum file size for uploads?",
    answer:
      "The free plan supports files up to 100MB. Pro and Enterprise plans support larger files up to 500MB and 2GB respectively.",
  },
  {
    question: "Can I customize the AR experience branding?",
    answer:
      "Yes! You can customize your workspace logo, brand colors, and AR background environment in the Settings > Branding section.",
  },
  {
    question: "How do I share AR models with customers?",
    answer:
      "After uploading a model, you'll get a unique AR link and QR code. Share these via your website, social media, or print materials. Users can view the AR experience directly in their mobile browser.",
  },
];

export default function Help() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-display font-bold" data-testid="text-help-title">
          How can we help you?
        </h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Find answers, watch tutorials, and get support for your WebAR journey
        </p>
      </div>

      {/* Search */}
      <Card className="max-w-2xl mx-auto">
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Search for help articles..."
              className="pl-12 h-12"
              data-testid="input-search-help"
            />
          </div>
        </CardContent>
      </Card>

      {/* Categories */}
      <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
        {categories.map((category) => (
          <Card key={category.title} className="hover-elevate transition-all" data-testid={`card-${category.title.toLowerCase().replace(/\s+/g, '-')}`}>
            <CardHeader>
              <CardTitle className="flex items-center gap-3 font-display">
                <div className="p-2 rounded-lg bg-primary/10">
                  <category.icon className="h-5 w-5 text-primary" />
                </div>
                {category.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {category.articles.map((article) => (
                  <li key={article}>
                    <Button
                      variant="ghost"
                      className="w-full justify-between hover-elevate"
                      data-testid={`link-${article.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      <span className="text-left">{article}</span>
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* FAQ */}
      <div className="max-w-4xl mx-auto space-y-6">
        <h2 className="text-2xl font-display font-bold">Frequently Asked Questions</h2>
        <Accordion type="single" collapsible className="space-y-3">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`} className="border rounded-lg px-6">
              <AccordionTrigger
                className="hover:no-underline"
                data-testid={`faq-question-${index}`}
              >
                <span className="text-left font-medium">{faq.question}</span>
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground" data-testid={`faq-answer-${index}`}>
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>

      {/* Contact Support */}
      <Card className="max-w-4xl mx-auto border-primary/20">
        <CardContent className="flex items-center justify-between p-6">
          <div className="space-y-1">
            <h3 className="font-display font-semibold text-lg">Still need help?</h3>
            <p className="text-muted-foreground">
              Our support team is here to assist you
            </p>
          </div>
          <Button data-testid="button-contact-support">
            <MessageCircle className="h-4 w-4 mr-2" />
            Contact Support
          </Button>
        </CardContent>
      </Card>

      {/* Documentation Link */}
      <div className="text-center">
        <Button variant="outline" data-testid="button-view-docs">
          <Book className="h-4 w-4 mr-2" />
          View Full Documentation
          <ExternalLink className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}
