import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TrendingUp, Eye, Scan, Clock, Users } from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
} from "recharts";
import { useWorkspaceAnalytics } from "@/hooks/use-analytics";
import { useWorkspaceContext } from "@/contexts/workspace-context";
import { Skeleton } from "@/components/ui/skeleton";

export default function Analytics() {
  const [timeRange, setTimeRange] = useState("7d");
  const { currentWorkspaceId, isLoading: workspaceLoading } = useWorkspaceContext();
  const { data: analyticsEvents = [], isLoading } = useWorkspaceAnalytics(currentWorkspaceId);

  // Process analytics data
  const { stats, viewsData, topModelsData } = useMemo(() => {
    const totalViews = analyticsEvents.filter(e => e.eventType === "view").length;
    const totalLaunches = analyticsEvents.filter(e => e.eventType === "ar_launch").length;
    const avgSession = analyticsEvents.reduce((acc, e) => acc + (e.duration || 0), 0) / (analyticsEvents.length || 1);
    
    // Aggregate data for charts - group by day of week
    const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const viewsByDay = new Map();
    const launchesByDay = new Map();
    
    analyticsEvents.forEach(event => {
      const date = new Date(event.timestamp);
      const dayName = dayNames[date.getDay()];
      
      if (event.eventType === "view") {
        viewsByDay.set(dayName, (viewsByDay.get(dayName) || 0) + 1);
      } else if (event.eventType === "ar_launch") {
        launchesByDay.set(dayName, (launchesByDay.get(dayName) || 0) + 1);
      }
    });
    
    const chartData = dayNames.map(day => ({
      name: day,
      views: viewsByDay.get(day) || 0,
      arLaunches: launchesByDay.get(day) || 0,
    }));
    
    // Aggregate top models by launches
    const modelCounts = new Map<string, number>();
    analyticsEvents
      .filter(e => e.eventType === "ar_launch" && e.modelId)
      .forEach(event => {
        modelCounts.set(event.modelId!, (modelCounts.get(event.modelId!) || 0) + 1);
      });
    
    const topModels = Array.from(modelCounts.entries())
      .map(([modelId, count]) => ({ name: `Model ${modelId.substring(0, 8)}`, launches: count }))
      .sort((a, b) => b.launches - a.launches)
      .slice(0, 5);
    
    if (topModels.length === 0) {
      topModels.push({ name: "No data", launches: 0 });
    }
    
    return {
      stats: {
        totalViews,
        totalLaunches,
        avgSession: Math.round(avgSession),
        uniqueUsers: new Set(analyticsEvents.map(e => e.sessionId)).size,
      },
      viewsData: chartData,
      topModelsData: topModels,
    };
  }, [analyticsEvents]);

  if (workspaceLoading || isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="pt-6">
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold" data-testid="text-analytics-title">
            Analytics
          </h1>
          <p className="text-muted-foreground mt-1">
            Track AR performance and engagement metrics
          </p>
        </div>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-[180px]" data-testid="select-time-range">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7d">Last 7 days</SelectItem>
            <SelectItem value="30d">Last 30 days</SelectItem>
            <SelectItem value="90d">Last 90 days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Stats Overview */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card data-testid="card-stat-total-views">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Views
            </CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalViews}</div>
            <p className="text-xs text-muted-foreground mt-1">
              +0% from last period
            </p>
          </CardContent>
        </Card>
        <Card data-testid="card-stat-ar-launches">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              AR Launches
            </CardTitle>
            <Scan className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalLaunches}</div>
            <p className="text-xs text-muted-foreground mt-1">
              +0% from last period
            </p>
          </CardContent>
        </Card>
        <Card data-testid="card-stat-avg-session">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Avg. Session
            </CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgSession}s</div>
            <p className="text-xs text-muted-foreground mt-1">
              +0% from last period
            </p>
          </CardContent>
        </Card>
        <Card data-testid="card-stat-unique-users">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Unique Users
            </CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.uniqueUsers}</div>
            <p className="text-xs text-muted-foreground mt-1">
              +0% from last period
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
          <TabsTrigger value="models" data-testid="tab-models">Models</TabsTrigger>
          <TabsTrigger value="devices" data-testid="tab-devices">Devices</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Views & AR Launches</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={viewsData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis
                    dataKey="name"
                    className="text-xs"
                    tick={{ fill: "hsl(var(--muted-foreground))" }}
                  />
                  <YAxis
                    className="text-xs"
                    tick={{ fill: "hsl(var(--muted-foreground))" }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="views"
                    stroke="hsl(var(--chart-1))"
                    strokeWidth={2}
                    dot={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="arLaunches"
                    stroke="hsl(var(--chart-2))"
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="models" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Top Performing Models</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={topModelsData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis
                    dataKey="name"
                    className="text-xs"
                    tick={{ fill: "hsl(var(--muted-foreground))" }}
                  />
                  <YAxis
                    className="text-xs"
                    tick={{ fill: "hsl(var(--muted-foreground))" }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                  <Bar
                    dataKey="launches"
                    fill="hsl(var(--chart-1))"
                    radius={[8, 8, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="devices" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Device Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="text-center py-12 text-muted-foreground">
              No device data available yet
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
