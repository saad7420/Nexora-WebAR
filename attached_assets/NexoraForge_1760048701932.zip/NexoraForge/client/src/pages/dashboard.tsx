import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, TrendingUp, Eye, Scan, Clock } from "lucide-react";
import { Link } from "wouter";
import { useProjects } from "@/hooks/use-projects";
import { useWorkspaceModels } from "@/hooks/use-models";
import { useWorkspaceAnalytics } from "@/hooks/use-analytics";
import { useWorkspaceContext } from "@/contexts/workspace-context";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { currentWorkspaceId, isLoading: workspaceLoading } = useWorkspaceContext();
  const { data: projects = [], isLoading: projectsLoading } = useProjects(currentWorkspaceId);
  const { data: analyticsEvents = [], isLoading: analyticsLoading } = useWorkspaceAnalytics(currentWorkspaceId);
  
  // Get all models for workspace
  const { data: models = [], isLoading: modelsLoading } = useWorkspaceModels(currentWorkspaceId);

  const isLoading = projectsLoading || analyticsLoading || modelsLoading;

  if (workspaceLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="pt-6">
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const stats = useMemo(() => {
    const totalLaunches = analyticsEvents.filter(e => e.eventType === "ar_launch").length;
    const avgSession = analyticsEvents.reduce((acc, e) => acc + (e.duration || 0), 0) / (analyticsEvents.length || 1);
    
    return [
      {
        title: "Total Projects",
        value: projects.length.toString(),
        change: "+0%",
        icon: TrendingUp,
        trend: "up" as const,
      },
      {
        title: "3D Models",
        value: models.length.toString(),
        change: "+0%",
        icon: Eye,
        trend: "up" as const,
      },
      {
        title: "AR Launches",
        value: totalLaunches.toString(),
        change: "+0%",
        icon: Scan,
        trend: "up" as const,
      },
      {
        title: "Avg. Session",
        value: `${Math.round(avgSession)}s`,
        change: "+0%",
        icon: Clock,
        trend: "neutral" as const,
      },
    ];
  }, [projects, models, analyticsEvents]);

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-4 w-64" />
          </div>
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="pt-6">
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold" data-testid="text-dashboard-title">
            Dashboard
          </h1>
          <p className="text-muted-foreground mt-1">
            Welcome back to your WebAR workspace
          </p>
        </div>
        <div className="flex gap-3">
          <Link href="/projects/new">
            <Button data-testid="button-new-project">
              <Plus className="h-4 w-4 mr-2" />
              New Project
            </Button>
          </Link>
          <Link href="/models/upload">
            <Button variant="outline" data-testid="button-upload-model">
              <Plus className="h-4 w-4 mr-2" />
              Upload Model
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title} data-testid={`card-stat-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid={`text-stat-value-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
                {stat.value}
              </div>
              <p className={`text-xs ${stat.trend === 'up' ? 'text-chart-4' : 'text-muted-foreground'} mt-1`}>
                {stat.change} from last month
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Empty State */}
      <Card className="border-dashed">
        <CardContent className="flex flex-col items-center justify-center py-16">
          <div className="rounded-full bg-primary/10 p-6 mb-4">
            <Plus className="h-12 w-12 text-primary" />
          </div>
          <h3 className="text-xl font-display font-semibold mb-2">
            Get started with your first project
          </h3>
          <p className="text-muted-foreground text-center max-w-md mb-6">
            Create a project to organize your 3D models and AR experiences. Upload models, customize them, and share via QR codes.
          </p>
          <Link href="/projects/new">
            <Button size="lg" data-testid="button-create-first-project">
              <Plus className="h-5 w-5 mr-2" />
              Create Your First Project
            </Button>
          </Link>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="font-display">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            No recent activity yet
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
