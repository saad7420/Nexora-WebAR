import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Building2, User, Bell, Palette, CreditCard, Upload } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Settings() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-display font-bold" data-testid="text-settings-title">
          Settings
        </h1>
        <p className="text-muted-foreground mt-1">
          Manage your workspace preferences and configurations
        </p>
      </div>

      <Tabs defaultValue="workspace" className="space-y-6">
        <TabsList>
          <TabsTrigger value="workspace" data-testid="tab-workspace">
            <Building2 className="h-4 w-4 mr-2" />
            Workspace
          </TabsTrigger>
          <TabsTrigger value="profile" data-testid="tab-profile">
            <User className="h-4 w-4 mr-2" />
            Profile
          </TabsTrigger>
          <TabsTrigger value="notifications" data-testid="tab-notifications">
            <Bell className="h-4 w-4 mr-2" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="branding" data-testid="tab-branding">
            <Palette className="h-4 w-4 mr-2" />
            Branding
          </TabsTrigger>
          <TabsTrigger value="billing" data-testid="tab-billing">
            <CreditCard className="h-4 w-4 mr-2" />
            Billing
          </TabsTrigger>
        </TabsList>

        <TabsContent value="workspace" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Workspace Information</CardTitle>
              <CardDescription>
                Update your workspace details and settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="workspace-name">Workspace Name</Label>
                <Input
                  id="workspace-name"
                  defaultValue="Demo Workspace"
                  data-testid="input-workspace-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="workspace-slug">Workspace URL</Label>
                <div className="flex gap-2">
                  <Input
                    id="workspace-slug"
                    defaultValue="demo-workspace"
                    data-testid="input-workspace-slug"
                  />
                  <span className="flex items-center text-muted-foreground text-sm whitespace-nowrap">
                    .nexora.app
                  </span>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="workspace-description">Description</Label>
                <Input
                  id="workspace-description"
                  placeholder="Brief description of your workspace"
                  data-testid="input-workspace-description"
                />
              </div>
              <div className="pt-4">
                <Button data-testid="button-save-workspace">Save Changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Profile Settings</CardTitle>
              <CardDescription>
                Manage your personal account information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-6">
                <Avatar className="h-20 w-20">
                  <AvatarImage src="" />
                  <AvatarFallback className="bg-primary text-primary-foreground text-2xl">
                    JD
                  </AvatarFallback>
                </Avatar>
                <div className="space-y-2">
                  <Label>Profile Picture</Label>
                  <Button variant="outline" size="sm" data-testid="button-upload-avatar">
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Photo
                  </Button>
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="profile-name">Full Name</Label>
                  <Input
                    id="profile-name"
                    defaultValue="John Doe"
                    data-testid="input-profile-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="profile-email">Email</Label>
                  <Input
                    id="profile-email"
                    type="email"
                    defaultValue="john@example.com"
                    data-testid="input-profile-email"
                  />
                </div>
              </div>
              <div className="pt-4">
                <Button data-testid="button-save-profile">Save Changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Notification Preferences</CardTitle>
              <CardDescription>
                Choose what updates you want to receive
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label>Model Upload Complete</Label>
                  <p className="text-sm text-muted-foreground">
                    Get notified when your 3D model conversion is complete
                  </p>
                </div>
                <Switch defaultChecked data-testid="switch-notify-upload" />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label>AR Launch Alerts</Label>
                  <p className="text-sm text-muted-foreground">
                    Receive alerts when someone views your AR models
                  </p>
                </div>
                <Switch data-testid="switch-notify-ar-launch" />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label>Team Updates</Label>
                  <p className="text-sm text-muted-foreground">
                    Get notified about team member activities
                  </p>
                </div>
                <Switch defaultChecked data-testid="switch-notify-team" />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label>Billing & Subscription</Label>
                  <p className="text-sm text-muted-foreground">
                    Important updates about your subscription
                  </p>
                </div>
                <Switch defaultChecked data-testid="switch-notify-billing" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="branding" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="font-display">AR Experience Branding</CardTitle>
              <CardDescription>
                Customize the look of your AR experiences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-6">
                <div className="h-20 w-20 rounded-lg bg-muted flex items-center justify-center border">
                  <Building2 className="h-10 w-10 text-muted-foreground" />
                </div>
                <div className="space-y-2">
                  <Label>Workspace Logo</Label>
                  <Button variant="outline" size="sm" data-testid="button-upload-logo">
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Logo
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="brand-color">Primary Brand Color</Label>
                <div className="flex gap-3">
                  <Input
                    id="brand-color"
                    type="color"
                    defaultValue="#6366F1"
                    className="w-20 h-10"
                    data-testid="input-brand-color"
                  />
                  <Input
                    defaultValue="#6366F1"
                    className="flex-1"
                    data-testid="input-brand-color-hex"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="ar-background">AR Background Style</Label>
                <Select defaultValue="studio">
                  <SelectTrigger id="ar-background" data-testid="select-ar-background">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="studio">Studio Lighting</SelectItem>
                    <SelectItem value="transparent">Transparent</SelectItem>
                    <SelectItem value="custom">Custom Environment</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="pt-4">
                <Button data-testid="button-save-branding">Save Changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Current Plan</CardTitle>
              <CardDescription>
                Manage your subscription and billing
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between p-4 rounded-lg border bg-muted/50">
                <div>
                  <h4 className="font-semibold text-lg">Free Plan</h4>
                  <p className="text-sm text-muted-foreground">
                    3 models • 100MB storage
                  </p>
                </div>
                <Button data-testid="button-upgrade-plan">Upgrade Plan</Button>
              </div>
              <div className="space-y-3">
                <h4 className="font-semibold">Usage This Month</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Models</span>
                    <span>0 / 3</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary" style={{ width: "0%" }} />
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Storage</span>
                    <span>0 MB / 100 MB</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary" style={{ width: "0%" }} />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
