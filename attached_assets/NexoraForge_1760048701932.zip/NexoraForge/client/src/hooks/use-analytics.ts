import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { AnalyticsEvent, InsertAnalyticsEvent } from "@shared/schema";

export function useWorkspaceAnalytics(workspaceId: string, limit: number = 100) {
  return useQuery<AnalyticsEvent[]>({
    queryKey: ["/api/workspaces", workspaceId, "analytics", limit],
    queryFn: async () => {
      const res = await fetch(`/api/workspaces/${workspaceId}/analytics?limit=${limit}`);
      if (!res.ok) throw new Error("Failed to fetch analytics");
      return res.json();
    },
    enabled: !!workspaceId,
  });
}

export function useProjectAnalytics(projectId: string, limit: number = 100) {
  return useQuery<AnalyticsEvent[]>({
    queryKey: ["/api/projects", projectId, "analytics", limit],
    queryFn: async () => {
      const res = await fetch(`/api/projects/${projectId}/analytics?limit=${limit}`);
      if (!res.ok) throw new Error("Failed to fetch analytics");
      return res.json();
    },
    enabled: !!projectId,
  });
}

export function useModelAnalytics(modelId: string, limit: number = 100) {
  return useQuery<AnalyticsEvent[]>({
    queryKey: ["/api/models", modelId, "analytics", limit],
    queryFn: async () => {
      const res = await fetch(`/api/models/${modelId}/analytics?limit=${limit}`);
      if (!res.ok) throw new Error("Failed to fetch analytics");
      return res.json();
    },
    enabled: !!modelId,
  });
}

export function useTrackAnalytics() {
  return useMutation({
    mutationFn: async (data: InsertAnalyticsEvent) => {
      const res = await apiRequest("POST", "/api/analytics/track", data);
      return res.json();
    },
  });
}
