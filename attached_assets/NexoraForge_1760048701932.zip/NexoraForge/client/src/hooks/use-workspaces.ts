import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Workspace, InsertWorkspace } from "@shared/schema";

export function useWorkspaces() {
  return useQuery<Workspace[]>({
    queryKey: ["/api/workspaces"],
  });
}

export function useCreateWorkspace() {
  return useMutation({
    mutationFn: async (data: InsertWorkspace) => {
      const res = await apiRequest("POST", "/api/workspaces", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workspaces"] });
    },
  });
}

export function useUpdateWorkspace() {
  return useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertWorkspace> }) => {
      const res = await apiRequest("PATCH", `/api/workspaces/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workspaces"] });
    },
  });
}
