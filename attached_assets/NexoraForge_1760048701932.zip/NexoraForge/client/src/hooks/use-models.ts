import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Model, InsertModel } from "@shared/schema";

// Get all models for a workspace
export function useWorkspaceModels(workspaceId: string) {
  return useQuery<Model[]>({
    queryKey: ["/api/workspaces", workspaceId, "models"],
    queryFn: async () => {
      const res = await fetch(`/api/workspaces/${workspaceId}/models`);
      if (!res.ok) throw new Error("Failed to fetch workspace models");
      return res.json();
    },
    enabled: !!workspaceId,
  });
}

export function useModels(projectId: string) {
  return useQuery<Model[]>({
    queryKey: ["/api/projects", projectId, "models"],
    queryFn: async () => {
      const res = await fetch(`/api/projects/${projectId}/models`);
      if (!res.ok) throw new Error("Failed to fetch models");
      return res.json();
    },
    enabled: !!projectId,
  });
}

export function useModel(id: string) {
  return useQuery<Model>({
    queryKey: ["/api/models", id],
    enabled: !!id,
  });
}

export function useUploadModel() {
  return useMutation({
    mutationFn: async ({ file, data }: { file: File; data: Partial<InsertModel> }) => {
      const formData = new FormData();
      formData.append("file", file);
      
      // Append all model data fields
      Object.entries(data).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          formData.append(key, typeof value === 'object' ? JSON.stringify(value) : String(value));
        }
      });

      const res = await fetch("/api/models/upload", {
        method: "POST",
        body: formData,
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Upload failed");
      }

      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", data.projectId, "models"] });
      queryClient.invalidateQueries({ queryKey: ["/api/workspaces"] });
    },
  });
}

export function useUpdateModel() {
  return useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertModel> }) => {
      const res = await apiRequest("PATCH", `/api/models/${id}`, data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/models", data.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects", data.projectId, "models"] });
      queryClient.invalidateQueries({ queryKey: ["/api/workspaces"] });
    },
  });
}

export function useDeleteModel() {
  return useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("DELETE", `/api/models/${id}`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/workspaces"] });
    },
  });
}
