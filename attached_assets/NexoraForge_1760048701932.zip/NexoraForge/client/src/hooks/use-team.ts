import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { WorkspaceMember, InsertWorkspaceMember } from "@shared/schema";

export function useWorkspaceMembers(workspaceId: string) {
  return useQuery<WorkspaceMember[]>({
    queryKey: ["/api/workspaces", workspaceId, "members"],
    queryFn: async () => {
      const res = await fetch(`/api/workspaces/${workspaceId}/members`);
      if (!res.ok) throw new Error("Failed to fetch members");
      return res.json();
    },
    enabled: !!workspaceId,
  });
}

export function useInviteMember() {
  return useMutation({
    mutationFn: async (data: InsertWorkspaceMember) => {
      const res = await apiRequest("POST", `/api/workspaces/${data.workspaceId}/members`, data);
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/workspaces", variables.workspaceId, "members"] });
    },
  });
}

export function useUpdateMemberRole() {
  return useMutation({
    mutationFn: async ({ id, role }: { id: string; role: "admin" | "editor" | "viewer" }) => {
      const res = await apiRequest("PATCH", `/api/workspace-members/${id}/role`, { role });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workspaces"] });
    },
  });
}

export function useRemoveMember() {
  return useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("DELETE", `/api/workspace-members/${id}`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workspaces"] });
    },
  });
}
