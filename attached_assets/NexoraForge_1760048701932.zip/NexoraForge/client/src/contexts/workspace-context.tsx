import { createContext, useContext, useState, useEffect } from "react";
import { useWorkspaces, useCreateWorkspace } from "@/hooks/use-workspaces";

interface WorkspaceContextType {
  currentWorkspaceId: string;
  setCurrentWorkspaceId: (id: string) => void;
  isLoading: boolean;
}

const WorkspaceContext = createContext<WorkspaceContextType | undefined>(undefined);

export function WorkspaceProvider({ children }: { children: React.ReactNode }) {
  const { data: workspaces = [], isLoading } = useWorkspaces();
  const createWorkspace = useCreateWorkspace();
  const [currentWorkspaceId, setCurrentWorkspaceId] = useState<string>("");

  useEffect(() => {
    async function initializeWorkspace() {
      if (isLoading) return;

      if (workspaces.length > 0) {
        // Use the first workspace
        setCurrentWorkspaceId(workspaces[0].id);
      } else {
        // Create a default workspace
        try {
          const newWorkspace = await createWorkspace.mutateAsync({
            name: "My Workspace",
            plan: "free",
          });
          setCurrentWorkspaceId(newWorkspace.id);
        } catch (error) {
          console.error("Failed to create workspace:", error);
        }
      }
    }

    initializeWorkspace();
  }, [workspaces, isLoading]);

  return (
    <WorkspaceContext.Provider value={{ currentWorkspaceId, setCurrentWorkspaceId, isLoading: isLoading || !currentWorkspaceId }}>
      {children}
    </WorkspaceContext.Provider>
  );
}

export function useWorkspaceContext() {
  const context = useContext(WorkspaceContext);
  if (!context) {
    throw new Error("useWorkspaceContext must be used within a WorkspaceProvider");
  }
  return context;
}
