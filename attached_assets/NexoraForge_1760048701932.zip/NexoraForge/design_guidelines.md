# Nexora Design Guidelines
## 3D WebAR Platform for Restaurant Menu Experiences

---

## Design Approach

**Selected Framework**: Material Design 3 + Custom Premium Components  
**Rationale**: Nexora requires a robust, data-dense interface with clear hierarchy for workspace management, 3D model handling, and analytics visualization. Material Design provides strong patterns for complex dashboards while allowing customization for the premium WebAR experience.

**Core Principles**:
- **Precision & Clarity**: Technical 3D work demands pixel-perfect previews and clear status indicators
- **Dark-First Luxury**: Professional tools deserve a sophisticated dark interface with strategic accent usage
- **Spatial Hierarchy**: 3D content needs breathing room; data density balanced with whitespace

---

## Color System

### Dark Mode (Primary)
**Foundation Colors** (HSL format):
- `--bg-primary`: 215 30% 9% (deep navy-charcoal #0F1720)
- `--bg-surface`: 215 20% 12% (#161B23)
- `--bg-elevated`: 215 15% 16% (cards, modals)
- `--border-subtle`: 215 10% 20% (#24292f)
- `--border-strong`: 215 15% 30%

**Text Hierarchy**:
- `--text-primary`: 210 20% 98% (#F8FAFC)
- `--text-secondary`: 215 10% 65% (#98A0A8)
- `--text-muted`: 215 8% 45%

**Brand & Accent Colors**:
- `--primary`: 239 84% 67% (#6366F1) - main brand, CTAs, active states
- `--primary-hover`: 239 84% 72%
- `--accent-gold`: 45 86% 44% (#D4AC0D) - premium badges, "featured" tags only
- `--accent-cyan`: 187 85% 53% (#22D3EE) - interactive 3D controls, AR indicators
- `--success`: 142 76% 36% (conversion success, AR active)
- `--warning`: 38 92% 50% (processing states)
- `--error`: 0 84% 60% (failed uploads)

### Light Mode
- `--bg-primary`: 0 0% 100% (#FFFFFF)
- `--bg-surface`: 210 20% 98% (#F7F9FB)
- `--text-primary`: 215 30% 9%
- Primary/accent colors remain consistent for brand recognition

---

## Typography

**Font Stack**:
- **Primary**: Inter (400, 500, 600, 700) via Google Fonts - UI, data, forms
- **Display**: Manrope (600, 700) - dashboard headers, section titles
- **Monospace**: JetBrains Mono (400, 500) - model IDs, file sizes, technical data

**Scale & Usage**:
- **H1 Dashboard**: 32px/40px, Manrope 700 - workspace name, main dashboard title
- **H2 Section**: 24px/32px, Manrope 600 - project names, panel headers
- **H3 Card Header**: 18px/24px, Inter 600 - model cards, stat blocks
- **Body Large**: 16px/24px, Inter 400 - descriptions, help text
- **Body**: 14px/20px, Inter 400 - standard UI, table content
- **Caption**: 12px/16px, Inter 500 - labels, metadata, timestamps
- **Technical**: 13px/20px, JetBrains Mono 400 - file paths, dimensions, AR links

---

## Layout System

**Tailwind Spacing Primitives**: Use units of **2, 4, 6, 8, 12, 16, 24** for consistent rhythm
- Component padding: `p-4` to `p-6`
- Section spacing: `gap-8` to `gap-12`
- Page margins: `px-6 md:px-8 lg:px-12`
- Card spacing: `space-y-6`

**Grid Patterns**:
- Dashboard widgets: `grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4`
- Project cards: `grid-cols-1 md:grid-cols-2 lg:grid-cols-3` with `gap-6`
- Analytics charts: `grid-cols-1 lg:grid-cols-2` for comparative views
- Settings panels: single column `max-w-4xl` for readability

**Container Strategy**:
- Main content: `max-w-screen-2xl mx-auto px-6 lg:px-12`
- Modals/dialogs: `max-w-3xl` for model preview, `max-w-md` for confirmations
- 3D viewer: full-width panels with 16:9 or 4:3 aspect ratio containers

---

## Component Library

### Navigation
**Top Bar**: Fixed header with workspace switcher (dropdown with search), global search, notifications, user menu. Height: 64px, bg: `--bg-surface` with subtle border-bottom.

**Sidebar**: Persistent left nav (280px width) with:
- Workspace logo/name at top
- Icon + label navigation items (Dashboard, Projects, Models, Analytics, Team, Settings)
- Collapse to icon-only on mobile (<1024px)
- Active state: `--primary` left border + text, `--bg-elevated` background

**Quick Actions Dock** (optional): Floating "+ New" button (bottom-right) expanding to: Upload Model, Create Project, Invite Team

### Cards & Surfaces
**Project Card**:
- Thumbnail preview (16:9) with model count overlay badge
- Title + description (max 2 lines truncated)
- Footer: stats (views, AR launches), action menu (3-dot)
- Hover: subtle elevation increase, `--border-strong` outline

**Model Card**:
- Square 3D preview (1:1) with rotate-on-hover hint
- Status indicator (top-right): Processing/Ready/Error with color-coded dot
- Bottom info: name, file size, date uploaded
- Quick actions: Preview, Share, Edit (icon buttons)

**Stat Widget**:
- Large number (H2 size) with trend indicator (↑ +12%)
- Label below in `--text-secondary`
- Optional micro-chart (sparkline) for context
- Size: min-height 120px with `p-6`

### Forms & Inputs
**Upload Zone**:
- Dashed border `--border-subtle` with `--accent-cyan` on hover/drag
- Large icon (upload cloud) + "Drag GLB/GLTF/FBX here" text
- Supported formats list below in caption size
- Active drag state: solid `--accent-cyan` border, `--bg-elevated` background

**Text Inputs**:
- Height: 44px with `px-4 py-2`
- Border: `--border-subtle` default, `--primary` focus
- Dark fill: `--bg-elevated` with `--text-primary`
- Labels: 12px above input in `--text-secondary`

**Buttons**:
- **Primary**: `--primary` background, white text, 44px height, `px-6 rounded-lg`
- **Secondary**: `--bg-elevated` background, `--text-primary`, border `--border-strong`
- **Outline on images**: Blurred background (backdrop-filter: blur(8px)), white border, white text
- **Icon-only**: 40px square, rounded-lg, `--bg-elevated` hover

### Data Display
**Table (Project/Model Lists)**:
- Alternating row: subtle `--bg-surface` / transparent
- Header: sticky top, `--text-secondary` caps, 12px font
- Rows: 56px height with `px-4 py-3`
- Hover: `--bg-elevated` background
- Actions column: icon buttons revealed on row hover

**Charts (Analytics)**:
- Use Recharts/Chart.js with custom colors: `--primary`, `--accent-cyan`, `--accent-gold`
- Grid lines: `--border-subtle`
- Tooltips: `--bg-elevated` with `--text-primary`
- Legend: horizontal below chart, 12px labels

### 3D Viewer Panel
**Model Viewer** (using model-viewer/Three.js):
- Container: full-width with 16:9 aspect ratio (`aspect-video`)
- Background: transparent for AR mode, dark gradient (`--bg-primary` to `--bg-surface`) for desktop preview
- Controls overlay (bottom): blurred panel with: Rotate, Scale, Lighting toggle, AR Launch button
- AR button: prominent `--accent-cyan` with glow effect, "View in Your Space" label
- Loading state: skeleton with pulsing animation

### Modals & Overlays
**Dialog**:
- Max-width: 600px (confirmation), 900px (model preview), full-screen (3D edit)
- Backdrop: `--bg-primary` at 80% opacity with blur
- Panel: `--bg-surface` with `--border-subtle` outline, rounded-xl
- Header: 64px height with title (H3) and close button
- Footer: actions right-aligned with 16px gap

---

## Interactive States

**Hover**: Increase elevation (subtle shadow), lighten background by 4-8%
**Active/Pressed**: Darken background by 8%, scale(0.98) for buttons
**Focus**: 2px solid `--primary` outline with 2px offset
**Disabled**: 40% opacity, cursor not-allowed
**Loading**: Skeleton screens with shimmer gradient animation (not spinners unless compact)

---

## Animations

**Principle**: Purposeful motion only - no decorative animations  
**Micro-interactions**:
- Button press: 100ms ease-out scale
- Card hover: 200ms ease elevation change
- Modal open: 250ms ease-out slide-up + fade
- 3D model load: fade-in 300ms after first render
- Chart render: 600ms ease-out draw animation (one-time)

**Transitions**: `transition-all duration-200 ease-in-out` for hover states

---

## Accessibility

- All interactive elements: min 44px touch target
- Color contrast: WCAG AAA for text (7:1), AA for UI (4.5:1)
- Focus indicators: always visible, never removed
- Dark mode: default; light mode toggle in settings
- Screen reader: proper ARIA labels for 3D viewer controls, upload status, chart data
- Keyboard nav: full support for all actions, Esc closes modals, Tab order logical

---

## Images & Media

### Hero Section (Dashboard Landing - First Login)
**Large Hero Image**: Full-width banner (1920x600) showing photorealistic 3D food model in AR context (person viewing dish on phone in restaurant setting). Overlay: semi-transparent gradient (`--bg-primary` 0% to 60% opacity) with CTA "Upload Your First Model"

### Empty States
- **No Projects**: Illustration of folder with upload icon, "Create your first project" CTA
- **No Models**: 3D wireframe graphic, "Upload 3D model to get started"
- Use custom illustrations in `--primary` and `--accent-cyan` color scheme

### Thumbnails
- Project cards: Auto-generated from first model or custom upload (400x225)
- Model cards: 3D render preview (400x400) with neutral studio lighting

---

## Responsive Behavior

**Breakpoints**:
- Mobile: < 768px (single column, bottom nav, stacked cards)
- Tablet: 768px - 1024px (2-column grids, sidebar collapses to icons)
- Desktop: 1024px - 1440px (3-column grids, full sidebar)
- Large: > 1440px (4-column grids, max-width constraint)

**Key Adaptations**:
- Navigation: Top bar persistent, sidebar converts to bottom nav on mobile
- Upload: Full-screen modal on mobile instead of inline
- 3D Viewer: Full-screen takeover on mobile with swipe gestures
- Tables: Horizontal scroll with sticky first column on tablet/mobile

---

## Unique Design Elements

**AR Status Indicator**: Animated cyan ring pulse around model cards when AR is active/being viewed  
**Conversion Progress**: Linear progress bar with file size/time remaining, color transitions from `--warning` to `--success`  
**3D Model Hotspots**: Floating info buttons (i icon) in cyan with tooltip on hover, positioned on model surface  
**Workspace Switcher**: Dropdown with workspace logos in grid, search bar, visual hierarchy for active workspace  
**Quick Share Panel**: Slide-out from right with QR code (large, scannable), short link with one-click copy, embed code snippet with syntax highlighting